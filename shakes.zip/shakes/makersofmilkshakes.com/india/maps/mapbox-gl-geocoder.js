(function(f) {
    if (typeof exports === "object" && typeof module !== "undefined") {
        module.exports = f()
    } else if (typeof define === "function" && define.amd) {
        define([], f)
    } else {
        var g;
        if (typeof window !== "undefined") {
            g = window
        } else if (typeof global !== "undefined") {
            g = global
        } else if (typeof self !== "undefined") {
            g = self
        } else {
            g = this
        }
        g.MapboxGeocoder = f()
    }
})(function() {
    var define, module, exports;
    return (function e(t, n, r) {
        function s(o, u) {
            if (!n[o]) {
                if (!t[o]) {
                    var a = typeof require == "function" && require;
                    if (!u && a) return a(o, !0);
                    if (i) return i(o, !0);
                    var f = new Error("Cannot find module '" + o + "'");
                    throw f.code = "MODULE_NOT_FOUND", f
                }
                var l = n[o] = {
                    exports: {}
                };
                t[o][0].call(l.exports, function(e) {
                    var n = t[o][1][e];
                    return s(n ? n : e)
                }, l, l.exports, e, t, n, r)
            }
            return n[o].exports
        }
        var i = typeof require == "function" && require;
        for (var o = 0; o < r.length; o++) s(r[o]);
        return s
    })({
        1: [function(require, module, exports) {
            module.exports = {
                'country.6646126669086080': {
                    'name': 'France',
                    'bbox': [
                        [-4.59235, 41.380007],
                        [9.560016, 51.148506]
                    ]
                },
                'country.12862386939497690': {
                    'name': 'United States',
                    'bbox': [
                        [-171.791111, 18.91619],
                        [-66.96466, 71.357764]
                    ]
                },
                'country.10299371396720960': {
                    'name': 'Russia',
                    'bbox': [
                        [19.66064, 41.151416],
                        [190.10042, 81.2504]
                    ]
                },
                'country.15589894856372040': {
                    'name': 'Canada',
                    'bbox': [
                        [-140.99778, 41.675105],
                        [-52.648099, 83.23324]
                    ]
                }
            };

        }, {}],
        2: [function(require, module, exports) {
            'use strict';

            var Typeahead = require('suggestions');
            var debounce = require('lodash.debounce');
            var extend = require('xtend');
            var EventEmitter = require('events').EventEmitter;
            var exceptions = require('./exceptions');
            var MapboxClient = require('mapbox/lib/services/geocoding');

            /**
             * A geocoder component using Mapbox Geocoding API
             * @class MapboxGeocoder
             *
             * @param {Object} options
             * @param {String} [options.accessToken=null] Required unless `mapboxgl.accessToken` is set globally
             * @param {Number} [options.zoom=16] On geocoded result what zoom level should the map animate to.
             * @param {Boolean} [options.flyTo=true] If false, animating the map to a selected result is disabled.
             * @param {String} [options.placeholder="Search"] Override the default placeholder attribute value.
             * @example
             * var geocoder = new MapboxGeocoder();
             * map.addControl(geocoder);
             * @return {MapboxGeocoder} `this`
             */
            function MapboxGeocoder(options) {
                this._eventEmitter = new EventEmitter();
                this.options = extend({}, this.options, options);
            }

            MapboxGeocoder.prototype = {

                options: {
                    placeholder: 'Search',
                    zoom: 16,
                    flyTo: true
                },

                onAdd: function(map) {
                    this._map = map;
                    this.mapboxClient = new MapboxClient(this.options.accessToken);
                    this._onChange = this._onChange.bind(this);
                    this._onKeyDown = this._onKeyDown.bind(this);
                    this._onQueryResult = this._onQueryResult.bind(this);
                    this._clear = this._clear.bind(this);

                    var el = this.container = document.createElement('div');
                    el.className = 'mapboxgl-ctrl-geocoder mapboxgl-ctrl';

                    var icon = document.createElement('span');
                    icon.className = 'geocoder-icon geocoder-icon-search';

                    this._inputEl = document.createElement('input');
                    this._inputEl.type = 'text';
                    this._inputEl.placeholder = this.options.placeholder;

                    this._inputEl.addEventListener('keydown', this._onKeyDown);
                    this._inputEl.addEventListener('change', this._onChange);

                    var actions = document.createElement('div');
                    actions.classList.add('geocoder-pin-right');

                    this._clearEl = document.createElement('button');
                    this._clearEl.className = 'geocoder-icon geocoder-icon-close';
                    this._clearEl.addEventListener('click', this._clear);

                    this._loadingEl = document.createElement('span');
                    this._loadingEl.className = 'geocoder-icon geocoder-icon-loading';

                    actions.appendChild(this._clearEl);
                    actions.appendChild(this._loadingEl);

                    el.appendChild(icon);
                    el.appendChild(this._inputEl);
                    el.appendChild(actions);

                    this._typeahead = new Typeahead(this._inputEl, [], {
                        filter: false
                    });
                    this._typeahead.getItemValue = function(item) {
                        return item.place_name;
                    };

                    return el;
                },

                onRemove: function() {
                    this.container.parentNode.removeChild(this.container);
                    this._map = null;
                    return this;
                },

                _onKeyDown: debounce(function(e) {
                    if (!e.target.value) {
                        return this._clearEl.style.display = 'none';
                    }

                    // TAB, ESC, LEFT, RIGHT, ENTER, UP, DOWN
                    if (e.metaKey || [9, 27, 37, 39, 13, 38, 40].indexOf(e.keyCode) !== -1) return;
                    this._geocode(e.target.value);
                }, 200),

                _onChange: function() {
                    if (this._inputEl.value) this._clearEl.style.display = 'block';
                    var selected = this._typeahead.selected;
                    if (selected) {
                        if (this.options.flyTo) {
                            if (!exceptions[selected.id] &&
                                (selected.bbox && selected.context && selected.context.length <= 3 ||
                                    selected.bbox && !selected.context)) {
                                var bbox = selected.bbox;
                                this._map.fitBounds([
                                    [bbox[0], bbox[1]],
                                    [bbox[2], bbox[3]]
                                ]);
                            } else if (exceptions[selected.id]) {
                                // Certain geocoder search results return (and therefore zoom to fit)
                                // an unexpectedly large bounding box: for example, both Russia and the
                                // USA span both sides of -180/180, or France includes the island of
                                // Reunion in the Indian Ocean. An incomplete list of these exceptions
                                // at ./exceptions.json provides "reasonable" bounding boxes as a
                                // short-term solution; this may be amended as necessary.
                                this._map.fitBounds(exceptions[selected.id].bbox);
                            } else {
                                this._map.flyTo({
                                    center: selected.center,
                                    zoom: this.options.zoom
                                });
                            }
                        }
                        this._eventEmitter.emit('result', {
                            result: selected
                        });
                    }
                },

                _geocode: function(searchInput) {
                    this._loadingEl.style.display = 'block';
                    this._eventEmitter.emit('loading');
                    var request = this.mapboxClient.geocodeForward(searchInput, this.options);

                    request.then(function(response) {
                        this._loadingEl.style.display = 'none';
                        var res = response.entity;
                        if (res.features.length) {
                            this._clearEl.style.display = 'block';
                        } else {
                            this._clearEl.style.display = 'none';
                            this._typeahead.selected = null;
                        }

                        this._eventEmitter.emit('results', res);
                        this._typeahead.update(res.features);
                    }.bind(this));

                    request.catch(function(err) {
                        this._loadingEl.style.display = 'none';
                        this._eventEmitter.emit('error', {
                            error: err
                        });
                    }.bind(this));

                    return request;
                },

                _clear: function() {
                    this._inputEl.value = '';
                    this._typeahead.selected = null;
                    this._typeahead.clear();
                    this._onChange();
                    this._inputEl.focus();
                    this._clearEl.style.display = 'none';
                    this._eventEmitter.emit('clear');
                },

                _onQueryResult: function(response) {
                    var results = response.entity;
                    if (!results.features.length) return;
                    var result = results.features[0];
                    this._typeahead.selected = result;
                    this._inputEl.value = result.place_name;
                    this._onChange();
                },

                /**
                 * Set & query the input
                 * @param {string} searchInput location name or other search input
                 * @returns {MapboxGeocoder} this
                 */
                query: function(searchInput) {
                    this._geocode(searchInput).then(this._onQueryResult);
                    return this;
                },

                /**
                 * Set input
                 * @param {string} searchInput location name or other search input
                 * @returns {MapboxGeocoder} this
                 */
                setInput: function(searchInput) {
                    // Set input value to passed value and clear everything else.
                    this._inputEl.value = searchInput;
                    this._typeahead.selected = null;
                    this._typeahead.clear();
                    this._onChange();
                    return this;
                },

                /**
                 * Subscribe to events that happen within the plugin.
                 * @param {String} type name of event. Available events and the data passed into their respective event objects are:
                 *
                 * - __clear__ `Emitted when the input is cleared`
                 * - __loading__ `Emitted when the geocoder is looking up a query`
                 * - __results__ `{ results } Fired when the geocoder returns a response`
                 * - __result__ `{ result } Fired when input is set`
                 * - __error__ `{ error } Error as string
                 * @param {Function} fn function that's called when the event is emitted.
                 * @returns {MapboxGeocoder} this;
                 */
                on: function(type, fn) {
                    this._eventEmitter.on(type, fn);
                    return this;
                },

                /**
                 * Remove an event
                 * @returns {MapboxGeocoder} this
                 * @param {String} type Event name.
                 * @param {Function} fn Function that should unsubscribe to the event emitted.
                 */
                off: function(type, fn) {
                    this._eventEmitter.removeListener(type, fn);
                    return this;
                }
            };

            module.exports = MapboxGeocoder;

        }, {
            "./exceptions": 1,
            "events": 3,
            "lodash.debounce": 5,
            "mapbox/lib/services/geocoding": 11,
            "suggestions": 43,
            "xtend": 47
        }],
        3: [function(require, module, exports) {
            // Copyright Joyent, Inc. and other Node contributors.
            //
            // Permission is hereby granted, free of charge, to any person obtaining a
            // copy of this software and associated documentation files (the
            // "Software"), to deal in the Software without restriction, including
            // without limitation the rights to use, copy, modify, merge, publish,
            // distribute, sublicense, and/or sell copies of the Software, and to permit
            // persons to whom the Software is furnished to do so, subject to the
            // following conditions:
            //
            // The above copyright notice and this permission notice shall be included
            // in all copies or substantial portions of the Software.
            //
            // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
            // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
            // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
            // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
            // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
            // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
            // USE OR OTHER DEALINGS IN THE SOFTWARE.

            function EventEmitter() {
                this._events = this._events || {};
                this._maxListeners = this._maxListeners || undefined;
            }
            module.exports = EventEmitter;

            // Backwards-compat with node 0.10.x
            EventEmitter.EventEmitter = EventEmitter;

            EventEmitter.prototype._events = undefined;
            EventEmitter.prototype._maxListeners = undefined;

            // By default EventEmitters will print a warning if more than 10 listeners are
            // added to it. This is a useful default which helps finding memory leaks.
            EventEmitter.defaultMaxListeners = 10;

            // Obviously not all Emitters should be limited to 10. This function allows
            // that to be increased. Set to zero for unlimited.
            EventEmitter.prototype.setMaxListeners = function(n) {
                if (!isNumber(n) || n < 0 || isNaN(n))
                    throw TypeError('n must be a positive number');
                this._maxListeners = n;
                return this;
            };

            EventEmitter.prototype.emit = function(type) {
                var er, handler, len, args, i, listeners;

                if (!this._events)
                    this._events = {};

                // If there is no 'error' event listener then throw.
                if (type === 'error') {
                    if (!this._events.error ||
                        (isObject(this._events.error) && !this._events.error.length)) {
                        er = arguments[1];
                        if (er instanceof Error) {
                            throw er; // Unhandled 'error' event
                        } else {
                            // At least give some kind of context to the user
                            var err = new Error('Uncaught, unspecified "error" event. (' + er + ')');
                            err.context = er;
                            throw err;
                        }
                    }
                }

                handler = this._events[type];

                if (isUndefined(handler))
                    return false;

                if (isFunction(handler)) {
                    switch (arguments.length) {
                        // fast cases
                        case 1:
                            handler.call(this);
                            break;
                        case 2:
                            handler.call(this, arguments[1]);
                            break;
                        case 3:
                            handler.call(this, arguments[1], arguments[2]);
                            break;
                            // slower
                        default:
                            args = Array.prototype.slice.call(arguments, 1);
                            handler.apply(this, args);
                    }
                } else if (isObject(handler)) {
                    args = Array.prototype.slice.call(arguments, 1);
                    listeners = handler.slice();
                    len = listeners.length;
                    for (i = 0; i < len; i++)
                        listeners[i].apply(this, args);
                }

                return true;
            };

            EventEmitter.prototype.addListener = function(type, listener) {
                var m;

                if (!isFunction(listener))
                    throw TypeError('listener must be a function');

                if (!this._events)
                    this._events = {};

                // To avoid recursion in the case that type === "newListener"! Before
                // adding it to the listeners, first emit "newListener".
                if (this._events.newListener)
                    this.emit('newListener', type,
                        isFunction(listener.listener) ?
                        listener.listener : listener);

                if (!this._events[type])
                    // Optimize the case of one listener. Don't need the extra array object.
                    this._events[type] = listener;
                else if (isObject(this._events[type]))
                    // If we've already got an array, just append.
                    this._events[type].push(listener);
                else
                    // Adding the second element, need to change to array.
                    this._events[type] = [this._events[type], listener];

                // Check for listener leak
                if (isObject(this._events[type]) && !this._events[type].warned) {
                    if (!isUndefined(this._maxListeners)) {
                        m = this._maxListeners;
                    } else {
                        m = EventEmitter.defaultMaxListeners;
                    }

                    if (m && m > 0 && this._events[type].length > m) {
                        this._events[type].warned = true;
                        console.error('(node) warning: possible EventEmitter memory ' +
                            'leak detected. %d listeners added. ' +
                            'Use emitter.setMaxListeners() to increase limit.',
                            this._events[type].length);
                        if (typeof console.trace === 'function') {
                            // not supported in IE 10
                            console.trace();
                        }
                    }
                }

                return this;
            };

            EventEmitter.prototype.on = EventEmitter.prototype.addListener;

            EventEmitter.prototype.once = function(type, listener) {
                if (!isFunction(listener))
                    throw TypeError('listener must be a function');

                var fired = false;

                function g() {
                    this.removeListener(type, g);

                    if (!fired) {
                        fired = true;
                        listener.apply(this, arguments);
                    }
                }

                g.listener = listener;
                this.on(type, g);

                return this;
            };

            // emits a 'removeListener' event iff the listener was removed
            EventEmitter.prototype.removeListener = function(type, listener) {
                var list, position, length, i;

                if (!isFunction(listener))
                    throw TypeError('listener must be a function');

                if (!this._events || !this._events[type])
                    return this;

                list = this._events[type];
                length = list.length;
                position = -1;

                if (list === listener ||
                    (isFunction(list.listener) && list.listener === listener)) {
                    delete this._events[type];
                    if (this._events.removeListener)
                        this.emit('removeListener', type, listener);

                } else if (isObject(list)) {
                    for (i = length; i-- > 0;) {
                        if (list[i] === listener ||
                            (list[i].listener && list[i].listener === listener)) {
                            position = i;
                            break;
                        }
                    }

                    if (position < 0)
                        return this;

                    if (list.length === 1) {
                        list.length = 0;
                        delete this._events[type];
                    } else {
                        list.splice(position, 1);
                    }

                    if (this._events.removeListener)
                        this.emit('removeListener', type, listener);
                }

                return this;
            };

            EventEmitter.prototype.removeAllListeners = function(type) {
                var key, listeners;

                if (!this._events)
                    return this;

                // not listening for removeListener, no need to emit
                if (!this._events.removeListener) {
                    if (arguments.length === 0)
                        this._events = {};
                    else if (this._events[type])
                        delete this._events[type];
                    return this;
                }

                // emit removeListener for all listeners on all events
                if (arguments.length === 0) {
                    for (key in this._events) {
                        if (key === 'removeListener') continue;
                        this.removeAllListeners(key);
                    }
                    this.removeAllListeners('removeListener');
                    this._events = {};
                    return this;
                }

                listeners = this._events[type];

                if (isFunction(listeners)) {
                    this.removeListener(type, listeners);
                } else if (listeners) {
                    // LIFO order
                    while (listeners.length)
                        this.removeListener(type, listeners[listeners.length - 1]);
                }
                delete this._events[type];

                return this;
            };

            EventEmitter.prototype.listeners = function(type) {
                var ret;
                if (!this._events || !this._events[type])
                    ret = [];
                else if (isFunction(this._events[type]))
                    ret = [this._events[type]];
                else
                    ret = this._events[type].slice();
                return ret;
            };

            EventEmitter.prototype.listenerCount = function(type) {
                if (this._events) {
                    var evlistener = this._events[type];

                    if (isFunction(evlistener))
                        return 1;
                    else if (evlistener)
                        return evlistener.length;
                }
                return 0;
            };

            EventEmitter.listenerCount = function(emitter, type) {
                return emitter.listenerCount(type);
            };

            function isFunction(arg) {
                return typeof arg === 'function';
            }

            function isNumber(arg) {
                return typeof arg === 'number';
            }

            function isObject(arg) {
                return typeof arg === 'object' && arg !== null;
            }

            function isUndefined(arg) {
                return arg === void 0;
            }

        }, {}],
        4: [function(require, module, exports) {
            // shim for using process in browser
            var process = module.exports = {};

            // cached from whatever global is present so that test runners that stub it
            // don't break things.  But we need to wrap it in a try catch in case it is
            // wrapped in strict mode code which doesn't define any globals.  It's inside a
            // function because try/catches deoptimize in certain engines.

            var cachedSetTimeout;
            var cachedClearTimeout;

            function defaultSetTimout() {
                throw new Error('setTimeout has not been defined');
            }

            function defaultClearTimeout() {
                throw new Error('clearTimeout has not been defined');
            }
            (function() {
                try {
                    if (typeof setTimeout === 'function') {
                        cachedSetTimeout = setTimeout;
                    } else {
                        cachedSetTimeout = defaultSetTimout;
                    }
                } catch (e) {
                    cachedSetTimeout = defaultSetTimout;
                }
                try {
                    if (typeof clearTimeout === 'function') {
                        cachedClearTimeout = clearTimeout;
                    } else {
                        cachedClearTimeout = defaultClearTimeout;
                    }
                } catch (e) {
                    cachedClearTimeout = defaultClearTimeout;
                }
            }())

            function runTimeout(fun) {
                if (cachedSetTimeout === setTimeout) {
                    //normal enviroments in sane situations
                    return setTimeout(fun, 0);
                }
                // if setTimeout wasn't available but was latter defined
                if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
                    cachedSetTimeout = setTimeout;
                    return setTimeout(fun, 0);
                }
                try {
                    // when when somebody has screwed with setTimeout but no I.E. maddness
                    return cachedSetTimeout(fun, 0);
                } catch (e) {
                    try {
                        // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
                        return cachedSetTimeout.call(null, fun, 0);
                    } catch (e) {
                        // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
                        return cachedSetTimeout.call(this, fun, 0);
                    }
                }


            }

            function runClearTimeout(marker) {
                if (cachedClearTimeout === clearTimeout) {
                    //normal enviroments in sane situations
                    return clearTimeout(marker);
                }
                // if clearTimeout wasn't available but was latter defined
                if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
                    cachedClearTimeout = clearTimeout;
                    return clearTimeout(marker);
                }
                try {
                    // when when somebody has screwed with setTimeout but no I.E. maddness
                    return cachedClearTimeout(marker);
                } catch (e) {
                    try {
                        // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
                        return cachedClearTimeout.call(null, marker);
                    } catch (e) {
                        // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
                        // Some versions of I.E. have different rules for clearTimeout vs setTimeout
                        return cachedClearTimeout.call(this, marker);
                    }
                }



            }
            var queue = [];
            var draining = false;
            var currentQueue;
            var queueIndex = -1;

            function cleanUpNextTick() {
                if (!draining || !currentQueue) {
                    return;
                }
                draining = false;
                if (currentQueue.length) {
                    queue = currentQueue.concat(queue);
                } else {
                    queueIndex = -1;
                }
                if (queue.length) {
                    drainQueue();
                }
            }

            function drainQueue() {
                if (draining) {
                    return;
                }
                var timeout = runTimeout(cleanUpNextTick);
                draining = true;

                var len = queue.length;
                while (len) {
                    currentQueue = queue;
                    queue = [];
                    while (++queueIndex < len) {
                        if (currentQueue) {
                            currentQueue[queueIndex].run();
                        }
                    }
                    queueIndex = -1;
                    len = queue.length;
                }
                currentQueue = null;
                draining = false;
                runClearTimeout(timeout);
            }

            process.nextTick = function(fun) {
                var args = new Array(arguments.length - 1);
                if (arguments.length > 1) {
                    for (var i = 1; i < arguments.length; i++) {
                        args[i - 1] = arguments[i];
                    }
                }
                queue.push(new Item(fun, args));
                if (queue.length === 1 && !draining) {
                    runTimeout(drainQueue);
                }
            };

            // v8 likes predictible objects
            function Item(fun, array) {
                this.fun = fun;
                this.array = array;
            }
            Item.prototype.run = function() {
                this.fun.apply(null, this.array);
            };
            process.title = 'browser';
            process.browser = true;
            process.env = {};
            process.argv = [];
            process.version = ''; // empty string to avoid regexp issues
            process.versions = {};

            function noop() {}

            process.on = noop;
            process.addListener = noop;
            process.once = noop;
            process.off = noop;
            process.removeListener = noop;
            process.removeAllListeners = noop;
            process.emit = noop;

            process.binding = function(name) {
                throw new Error('process.binding is not supported');
            };

            process.cwd = function() {
                return '/'
            };
            process.chdir = function(dir) {
                throw new Error('process.chdir is not supported');
            };
            process.umask = function() {
                return 0;
            };

        }, {}],
        5: [function(require, module, exports) {
            (function(global) {
                /**
                 * lodash (Custom Build) <https://lodash.com/>
                 * Build: `lodash modularize exports="npm" -o ./`
                 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
                 * Released under MIT license <https://lodash.com/license>
                 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
                 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
                 */

                /** Used as the `TypeError` message for "Functions" methods. */
                var FUNC_ERROR_TEXT = 'Expected a function';

                /** Used as references for various `Number` constants. */
                var NAN = 0 / 0;

                /** `Object#toString` result references. */
                var symbolTag = '[object Symbol]';

                /** Used to match leading and trailing whitespace. */
                var reTrim = /^\s+|\s+$/g;

                /** Used to detect bad signed hexadecimal string values. */
                var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

                /** Used to detect binary string values. */
                var reIsBinary = /^0b[01]+$/i;

                /** Used to detect octal string values. */
                var reIsOctal = /^0o[0-7]+$/i;

                /** Built-in method references without a dependency on `root`. */
                var freeParseInt = parseInt;

                /** Detect free variable `global` from Node.js. */
                var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

                /** Detect free variable `self`. */
                var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

                /** Used as a reference to the global object. */
                var root = freeGlobal || freeSelf || Function('return this')();

                /** Used for built-in method references. */
                var objectProto = Object.prototype;

                /**
                 * Used to resolve the
                 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
                 * of values.
                 */
                var objectToString = objectProto.toString;

                /* Built-in method references for those with the same name as other `lodash` methods. */
                var nativeMax = Math.max,
                    nativeMin = Math.min;

                /**
                 * Gets the timestamp of the number of milliseconds that have elapsed since
                 * the Unix epoch (1 January 1970 00:00:00 UTC).
                 *
                 * @static
                 * @memberOf _
                 * @since 2.4.0
                 * @category Date
                 * @returns {number} Returns the timestamp.
                 * @example
                 *
                 * _.defer(function(stamp) {
                 *   console.log(_.now() - stamp);
                 * }, _.now());
                 * // => Logs the number of milliseconds it took for the deferred invocation.
                 */
                var now = function() {
                    return root.Date.now();
                };

                /**
                 * Creates a debounced function that delays invoking `func` until after `wait`
                 * milliseconds have elapsed since the last time the debounced function was
                 * invoked. The debounced function comes with a `cancel` method to cancel
                 * delayed `func` invocations and a `flush` method to immediately invoke them.
                 * Provide `options` to indicate whether `func` should be invoked on the
                 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
                 * with the last arguments provided to the debounced function. Subsequent
                 * calls to the debounced function return the result of the last `func`
                 * invocation.
                 *
                 * **Note:** If `leading` and `trailing` options are `true`, `func` is
                 * invoked on the trailing edge of the timeout only if the debounced function
                 * is invoked more than once during the `wait` timeout.
                 *
                 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
                 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
                 *
                 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
                 * for details over the differences between `_.debounce` and `_.throttle`.
                 *
                 * @static
                 * @memberOf _
                 * @since 0.1.0
                 * @category Function
                 * @param {Function} func The function to debounce.
                 * @param {number} [wait=0] The number of milliseconds to delay.
                 * @param {Object} [options={}] The options object.
                 * @param {boolean} [options.leading=false]
                 *  Specify invoking on the leading edge of the timeout.
                 * @param {number} [options.maxWait]
                 *  The maximum time `func` is allowed to be delayed before it's invoked.
                 * @param {boolean} [options.trailing=true]
                 *  Specify invoking on the trailing edge of the timeout.
                 * @returns {Function} Returns the new debounced function.
                 * @example
                 *
                 * // Avoid costly calculations while the window size is in flux.
                 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
                 *
                 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
                 * jQuery(element).on('click', _.debounce(sendMail, 300, {
                 *   'leading': true,
                 *   'trailing': false
                 * }));
                 *
                 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
                 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
                 * var source = new EventSource('/stream');
                 * jQuery(source).on('message', debounced);
                 *
                 * // Cancel the trailing debounced invocation.
                 * jQuery(window).on('popstate', debounced.cancel);
                 */
                function debounce(func, wait, options) {
                    var lastArgs,
                        lastThis,
                        maxWait,
                        result,
                        timerId,
                        lastCallTime,
                        lastInvokeTime = 0,
                        leading = false,
                        maxing = false,
                        trailing = true;

                    if (typeof func != 'function') {
                        throw new TypeError(FUNC_ERROR_TEXT);
                    }
                    wait = toNumber(wait) || 0;
                    if (isObject(options)) {
                        leading = !!options.leading;
                        maxing = 'maxWait' in options;
                        maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
                        trailing = 'trailing' in options ? !!options.trailing : trailing;
                    }

                    function invokeFunc(time) {
                        var args = lastArgs,
                            thisArg = lastThis;

                        lastArgs = lastThis = undefined;
                        lastInvokeTime = time;
                        result = func.apply(thisArg, args);
                        return result;
                    }

                    function leadingEdge(time) {
                        // Reset any `maxWait` timer.
                        lastInvokeTime = time;
                        // Start the timer for the trailing edge.
                        timerId = setTimeout(timerExpired, wait);
                        // Invoke the leading edge.
                        return leading ? invokeFunc(time) : result;
                    }

                    function remainingWait(time) {
                        var timeSinceLastCall = time - lastCallTime,
                            timeSinceLastInvoke = time - lastInvokeTime,
                            result = wait - timeSinceLastCall;

                        return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
                    }

                    function shouldInvoke(time) {
                        var timeSinceLastCall = time - lastCallTime,
                            timeSinceLastInvoke = time - lastInvokeTime;

                        // Either this is the first call, activity has stopped and we're at the
                        // trailing edge, the system time has gone backwards and we're treating
                        // it as the trailing edge, or we've hit the `maxWait` limit.
                        return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
                            (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
                    }

                    function timerExpired() {
                        var time = now();
                        if (shouldInvoke(time)) {
                            return trailingEdge(time);
                        }
                        // Restart the timer.
                        timerId = setTimeout(timerExpired, remainingWait(time));
                    }

                    function trailingEdge(time) {
                        timerId = undefined;

                        // Only invoke if we have `lastArgs` which means `func` has been
                        // debounced at least once.
                        if (trailing && lastArgs) {
                            return invokeFunc(time);
                        }
                        lastArgs = lastThis = undefined;
                        return result;
                    }

                    function cancel() {
                        if (timerId !== undefined) {
                            clearTimeout(timerId);
                        }
                        lastInvokeTime = 0;
                        lastArgs = lastCallTime = lastThis = timerId = undefined;
                    }

                    function flush() {
                        return timerId === undefined ? result : trailingEdge(now());
                    }

                    function debounced() {
                        var time = now(),
                            isInvoking = shouldInvoke(time);

                        lastArgs = arguments;
                        lastThis = this;
                        lastCallTime = time;

                        if (isInvoking) {
                            if (timerId === undefined) {
                                return leadingEdge(lastCallTime);
                            }
                            if (maxing) {
                                // Handle invocations in a tight loop.
                                timerId = setTimeout(timerExpired, wait);
                                return invokeFunc(lastCallTime);
                            }
                        }
                        if (timerId === undefined) {
                            timerId = setTimeout(timerExpired, wait);
                        }
                        return result;
                    }
                    debounced.cancel = cancel;
                    debounced.flush = flush;
                    return debounced;
                }

                /**
                 * Checks if `value` is the
                 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
                 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
                 *
                 * @static
                 * @memberOf _
                 * @since 0.1.0
                 * @category Lang
                 * @param {*} value The value to check.
                 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
                 * @example
                 *
                 * _.isObject({});
                 * // => true
                 *
                 * _.isObject([1, 2, 3]);
                 * // => true
                 *
                 * _.isObject(_.noop);
                 * // => true
                 *
                 * _.isObject(null);
                 * // => false
                 */
                function isObject(value) {
                    var type = typeof value;
                    return !!value && (type == 'object' || type == 'function');
                }

                /**
                 * Checks if `value` is object-like. A value is object-like if it's not `null`
                 * and has a `typeof` result of "object".
                 *
                 * @static
                 * @memberOf _
                 * @since 4.0.0
                 * @category Lang
                 * @param {*} value The value to check.
                 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
                 * @example
                 *
                 * _.isObjectLike({});
                 * // => true
                 *
                 * _.isObjectLike([1, 2, 3]);
                 * // => true
                 *
                 * _.isObjectLike(_.noop);
                 * // => false
                 *
                 * _.isObjectLike(null);
                 * // => false
                 */
                function isObjectLike(value) {
                    return !!value && typeof value == 'object';
                }

                /**
                 * Checks if `value` is classified as a `Symbol` primitive or object.
                 *
                 * @static
                 * @memberOf _
                 * @since 4.0.0
                 * @category Lang
                 * @param {*} value The value to check.
                 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
                 * @example
                 *
                 * _.isSymbol(Symbol.iterator);
                 * // => true
                 *
                 * _.isSymbol('abc');
                 * // => false
                 */
                function isSymbol(value) {
                    return typeof value == 'symbol' ||
                        (isObjectLike(value) && objectToString.call(value) == symbolTag);
                }

                /**
                 * Converts `value` to a number.
                 *
                 * @static
                 * @memberOf _
                 * @since 4.0.0
                 * @category Lang
                 * @param {*} value The value to process.
                 * @returns {number} Returns the number.
                 * @example
                 *
                 * _.toNumber(3.2);
                 * // => 3.2
                 *
                 * _.toNumber(Number.MIN_VALUE);
                 * // => 5e-324
                 *
                 * _.toNumber(Infinity);
                 * // => Infinity
                 *
                 * _.toNumber('3.2');
                 * // => 3.2
                 */
                function toNumber(value) {
                    if (typeof value == 'number') {
                        return value;
                    }
                    if (isSymbol(value)) {
                        return NAN;
                    }
                    if (isObject(value)) {
                        var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
                        value = isObject(other) ? (other + '') : other;
                    }
                    if (typeof value != 'string') {
                        return value === 0 ? value : +value;
                    }
                    value = value.replace(reTrim, '');
                    var isBinary = reIsBinary.test(value);
                    return (isBinary || reIsOctal.test(value)) ?
                        freeParseInt(value.slice(2), isBinary ? 2 : 8) :
                        (reIsBadHex.test(value) ? NAN : +value);
                }

                module.exports = debounce;

            }).call(this, typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
        }, {}],
        6: [function(require, module, exports) {
            'use strict';

            if (typeof Promise === 'undefined') {
                // install ES6 Promise polyfill
                require('../vendor/promise');
            }

            var interceptor = require('rest/interceptor');

            var callbackify = interceptor({
                success: function(response) {
                    var callback = response && response.callback;

                    if (typeof callback === 'function') {
                        callback(null, response.entity, response);
                    }

                    return response;
                },
                error: function(response) {
                    var callback = response && response.callback;

                    if (typeof callback === 'function') {
                        var err = response.error || response.entity;
                        if (typeof err !== 'object') err = new Error(err);
                        callback(err);
                    }

                    return response;
                }
            });

            module.exports = callbackify;

        }, {
            "../vendor/promise": 42,
            "rest/interceptor": 18
        }],
        7: [function(require, module, exports) {
            'use strict';

            if (typeof Promise === 'undefined') {
                // install ES6 Promise polyfill
                require('../vendor/promise');
            }

            var rest = require('rest');
            var standardResponse = require('./standard_response');
            var callbackify = require('./callbackify');

            // rest.js client with MIME support
            module.exports = function(config) {
                return rest
                    .wrap(require('rest/interceptor/errorCode'))
                    .wrap(require('rest/interceptor/pathPrefix'), {
                        prefix: config.endpoint
                    })
                    .wrap(require('rest/interceptor/mime'), {
                        mime: 'application/json'
                    })
                    .wrap(require('rest/interceptor/params'))
                    .wrap(require('rest/interceptor/defaultRequest'), {
                        params: {
                            access_token: config.accessToken
                        }
                    })
                    .wrap(require('rest/interceptor/template'))
                    .wrap(standardResponse)
                    .wrap(callbackify);
            };

        }, {
            "../vendor/promise": 42,
            "./callbackify": 6,
            "./standard_response": 12,
            "rest": 14,
            "rest/interceptor/defaultRequest": 19,
            "rest/interceptor/errorCode": 20,
            "rest/interceptor/mime": 21,
            "rest/interceptor/params": 22,
            "rest/interceptor/pathPrefix": 23,
            "rest/interceptor/template": 24
        }],
        8: [function(require, module, exports) {
            // We keep all of the constants that declare endpoints in one
            // place, so that we could conceivably update this for API layout
            // revisions.
            module.exports.DEFAULT_ENDPOINT = 'https://api.mapbox.com';

            module.exports.API_GEOCODING_FORWARD = '/geocoding/v5/{dataset}/{query}.json{?proximity,country,types,bbox,limit}';
            module.exports.API_GEOCODING_REVERSE = '/geocoding/v5/{dataset}/{longitude},{latitude}.json{?types,limit}';

            module.exports.API_DIRECTIONS = '/v4/directions/{profile}/{encodedWaypoints}.json{?alternatives,instructions,geometry,steps}';
            module.exports.API_DISTANCE = '/distances/v1/mapbox/{profile}';

            module.exports.API_SURFACE = '/v4/surface/{mapid}.json{?layer,fields,points,geojson,interpolate,encoded_polyline}';

            module.exports.API_UPLOADS = '/uploads/v1/{owner}';
            module.exports.API_UPLOAD = '/uploads/v1/{owner}/{upload}';
            module.exports.API_UPLOAD_CREDENTIALS = '/uploads/v1/{owner}/credentials';

            module.exports.API_MATCHING = '/matching/v4/{profile}.json';

            module.exports.API_DATASET_DATASETS = '/datasets/v1/{owner}{?limit,start,fresh}';
            module.exports.API_DATASET_DATASET = '/datasets/v1/{owner}/{dataset}';
            module.exports.API_DATASET_FEATURES = '/datasets/v1/{owner}/{dataset}/features{?reverse,limit,start}';
            module.exports.API_DATASET_FEATURE = '/datasets/v1/{owner}/{dataset}/features/{id}';

            module.exports.API_TILESTATS_STATISTICS = '/tilestats/v1/{owner}/{tileset}';
            module.exports.API_TILESTATS_LAYER = '/tilestats/v1/{owner}/{tileset}/{layer}';
            module.exports.API_TILESTATS_ATTRIBUTE = '/tilestats/v1/{owner}/{tileset}/{layer}/{attribute}';

            module.exports.API_STATIC = '/v4/{mapid}{+overlay}/{+xyz}/{width}x{height}{+retina}{.format}{?access_token}';

            module.exports.API_STYLES_LIST = '/styles/v1/{owner}';
            module.exports.API_STYLES_CREATE = '/styles/v1/{owner}';
            module.exports.API_STYLES_READ = '/styles/v1/{owner}/{styleid}';
            module.exports.API_STYLES_UPDATE = '/styles/v1/{owner}/{styleid}';
            module.exports.API_STYLES_DELETE = '/styles/v1/{owner}/{styleid}';
            module.exports.API_STYLES_EMBED = '/styles/v1/{owner}/{styleid}.html{?zoomwheel,title,access_token}';
            module.exports.API_STYLES_SPRITE = '/styles/v1/{owner}/{styleid}/sprite{+retina}{.format}';
            module.exports.API_STYLES_SPRITE_ADD_ICON = '/styles/v1/{owner}/{styleid}/sprite/{iconName}';
            module.exports.API_STYLES_SPRITE_DELETE_ICON = '/styles/v1/{owner}/{styleid}/sprite/{iconName}';

            module.exports.API_STYLES_FONT_GLYPH_RANGES = '/fonts/v1/{owner}/{font}/{start}-{end}.pbf'

        }, {}],
        9: [function(require, module, exports) {
            'use strict';

            var b64 = require('rest/util/base64');

            /**
             * Access tokens actually are data, and using them we can derive
             * a user's username. This method attempts to do just that,
             * decoding the part of the token after the first `.` into
             * a username.
             *
             * @private
             * @param {string} token an access token
             * @return {string} username
             */
            function getUser(token) {
                var data = token.split('.')[1];
                if (!data) return null;
                data = data.replace(/-/g, '+').replace(/_/g, '/');

                var mod = data.length % 4;
                if (mod === 2) data += '==';
                if (mod === 3) data += '=';
                if (mod === 1 || mod > 3) return null;

                try {
                    return JSON.parse(b64.decode(data)).u;
                } catch (err) {
                    return null;
                }
            }

            module.exports = getUser;

        }, {
            "rest/util/base64": 33
        }],
        10: [function(require, module, exports) {
            'use strict';

            var invariant = require('../vendor/invariant');
            var constants = require('./constants');
            var client = require('./client');
            var getUser = require('./get_user');

            /**
             * Services all have the same constructor pattern: you initialize them
             * with an access token and options, and they validate those arguments
             * in a predictable way. This is a constructor-generator that makes
             * it possible to require each service's API individually.
             *
             * @private
             * @param {string} name the name of the Mapbox API this class will access:
             * this is set to the name of the function so it will show up in tracebacks
             * @returns {Function} constructor function
             */
            function makeService(name) {

                function service(accessToken, options) {
                    this.name = name;

                    invariant(typeof accessToken === 'string',
                        'accessToken required to instantiate Mapbox client');

                    var endpoint = constants.DEFAULT_ENDPOINT;

                    if (options !== undefined) {
                        invariant(typeof options === 'object', 'options must be an object');
                        if (options.endpoint) {
                            invariant(typeof options.endpoint === 'string', 'endpoint must be a string');
                            endpoint = options.endpoint;
                        }
                        if (options.account) {
                            invariant(typeof options.account === 'string', 'account must be a string');
                            this.owner = options.account;
                        }
                    }

                    this.client = client({
                        endpoint: endpoint,
                        accessToken: accessToken
                    });

                    this.accessToken = accessToken;
                    this.endpoint = endpoint;
                    this.owner = this.owner || getUser(accessToken);
                    invariant(!!this.owner, 'could not determine account from provided accessToken');

                }

                return service;
            }

            module.exports = makeService;

        }, {
            "../vendor/invariant": 41,
            "./client": 7,
            "./constants": 8,
            "./get_user": 9
        }],
        11: [function(require, module, exports) {
            'use strict';

            var invariant = require('../../vendor/invariant'),
                makeService = require('../make_service'),
                constants = require('../constants');

            var MapboxGeocoding = makeService('MapboxGeocoding');

            var REVERSE_GEOCODING_PRECISION = 5;
            var FORWARD_GEOCODING_PROXIMITY_PRECISION = 3;

            function roundTo(value, places) {
                var mult = Math.pow(10, places);
                return Math.round(value * mult) / mult;
            }

            /**
             * Search for a location with a string, using the
             * [Mapbox Geocoding API](https://www.mapbox.com/api-documentation/#geocoding).
             *
             * The `query` parmeter can be an array of strings only if batch geocoding
             * is used by specifying `mapbox.places-permanent` as the `dataset` option.
             *
             * @param {string|Array<string>} query desired location
             * @param {Object} [options={}] additional options meant to tune
             * the request
             * @param {Object} options.proximity a proximity argument: this is
             * a geographical point given as an object with latitude and longitude
             * properties. Search results closer to this point will be given
             * higher priority.
             * @param {Array} options.bbox a bounding box argument: this is
             * a bounding box given as an array in the format [minX, minY, maxX, maxY].
             * Search results will be limited to the bounding box.
             * @param {string} options.types a comma seperated list of types that filter
             * results to match those specified. See https://www.mapbox.com/developers/api/geocoding/#filter-type
             * for available types.
             * @param {number=5} options.limit is the maximum number of results to return, between 1 and 10 inclusive.
             * Some very specific queries may return fewer results than the limit.
             * @param {string} options.country a comma separated list of country codes to
             * limit results to specified country or countries.
             * @param {boolean=true} options.autocomplete whether to include results that include
             * the query only as a prefix. This is useful for UIs where users type
             * values, but if you have complete addresses as input, you'll want to turn it off
             * @param {string} [options.dataset=mapbox.places] the desired data to be
             * geocoded against. The default, mapbox.places, does not permit unlimited
             * caching. `mapbox.places-permanent` is available on request and does
             * permit permanent caching.
             * @param {Function} callback called with (err, results)
             * @returns {undefined} nothing, calls callback
             * @memberof MapboxClient
             * @example
             * var mapboxClient = new MapboxClient('ACCESSTOKEN');
             * mapboxClient.geocodeForward('Paris, France', function(err, res) {
             *   // res is a GeoJSON document with geocoding matches
             * });
             * // using the proximity option to weight results closer to texas
             * mapboxClient.geocodeForward('Paris, France', {
             *   proximity: { latitude: 33.6875431, longitude: -95.4431142 }
             * }, function(err, res) {
             *   // res is a GeoJSON document with geocoding matches
             * });
             * // using the bbox option to limit results to a portion of Washington, D.C.
             * mapboxClient.geocodeForward('Starbucks', {
             *   bbox: [-77.083056,38.908611,-76.997778,38.959167]
             * }, function(err, res) {
             *   // res is a GeoJSON document with geocoding matches
             * });
             */
            MapboxGeocoding.prototype.geocodeForward = function(query, options, callback) {

                // permit the options argument to be omitted
                if (callback === undefined && typeof options === 'function') {
                    callback = options;
                    options = {};
                }

                // typecheck arguments
                if (Array.isArray(query)) {
                    if (options.dataset !== 'mapbox.places-permanent') {
                        throw new Error('Batch geocoding is only available with the mapbox.places-permanent endpoint. See https://mapbox.com/api-documentation/#batch-requests for details')
                    } else {
                        query = query.join(';');
                    }
                }
                invariant(typeof query === 'string', 'query must be a string');
                invariant(typeof options === 'object', 'options must be an object');

                var queryOptions = {
                    query: query,
                    dataset: 'mapbox.places'
                };

                var autocomplete = true;
                var precision = FORWARD_GEOCODING_PROXIMITY_PRECISION;
                if (options.precision) {
                    invariant(typeof options.precision === 'number', 'precision option must be number');
                    precision = options.precision;
                }

                if (options.proximity) {
                    invariant(typeof options.proximity.latitude === 'number' &&
                        typeof options.proximity.longitude === 'number',
                        'proximity must be an object with numeric latitude & longitude properties');
                    queryOptions.proximity = roundTo(options.proximity.longitude, precision) + ',' + roundTo(options.proximity.latitude, precision);
                }

                if (options.bbox) {
                    invariant(typeof options.bbox[0] === 'number' &&
                        typeof options.bbox[1] === 'number' &&
                        typeof options.bbox[2] === 'number' &&
                        typeof options.bbox[3] === 'number' &&
                        options.bbox.length === 4,
                        'bbox must be an array with numeric values in the form [minX, minY, maxX, maxY]');
                    queryOptions.bbox = options.bbox[0] + "," + options.bbox[1] + "," + options.bbox[2] + "," + options.bbox[3];
                }

                if (options.limit) {
                    invariant(typeof options.limit === 'number',
                        'limit must be a number');
                    queryOptions.limit = options.limit;
                }

                if (options.dataset) {
                    invariant(typeof options.dataset === 'string', 'dataset option must be string');
                    queryOptions.dataset = options.dataset;
                }

                if (options.country) {
                    invariant(typeof options.country === 'string', 'country option must be string');
                    queryOptions.country = options.country;
                }

                if (options.types) {
                    invariant(typeof options.types === 'string', 'types option must be string');
                    queryOptions.types = options.types;
                }

                if (typeof options.autocomplete === 'boolean') {
                    invariant(typeof options.autocomplete === 'boolean', 'autocomplete must be a boolean');
                    queryOptions.autocomplete = options.autocomplete;
                }

                return this.client({
                    path: constants.API_GEOCODING_FORWARD,
                    params: queryOptions,
                    callback: callback
                });
            };

            /**
             * Given a location, determine what geographical features are located
             * there. This uses the [Mapbox Geocoding API](https://www.mapbox.com/api-documentation/#geocoding).
             *
             * @param {Object} location the geographical point to search
             * @param {number} location.latitude decimal degrees latitude, in range -90 to 90
             * @param {number} location.longitude decimal degrees longitude, in range -180 to 180
             * @param {Object} [options={}] additional options meant to tune
             * the request.
             * @param {string} options.types a comma seperated list of types that filter
             * results to match those specified. See 
             * https://www.mapbox.com/api-documentation/#retrieve-places-near-a-location
             * for available types.
             * @param {number=1} options.limit is the maximum number of results to return, between 1 and 5
             * inclusive. Requires a single options.types to be specified (see example).
             * @param {string} [options.dataset=mapbox.places] the desired data to be
             * geocoded against. The default, mapbox.places, does not permit unlimited
             * caching. `mapbox.places-permanent` is available on request and does
             * permit permanent caching.
             * @param {Function} callback called with (err, results)
             * @returns {undefined} nothing, calls callback
             * @example
             * var mapboxClient = new MapboxGeocoding('ACCESSTOKEN');
             * mapboxClient.geocodeReverse(
             *   { latitude: 33.6875431, longitude: -95.4431142 },
             *   function(err, res) {
             *   // res is a GeoJSON document with geocoding matches
             * });
             * @example
             * var mapboxClient = new MapboxGeocoding('ACCESSTOKEN');
             * mapboxClient.geocodeReverse(
             *   { latitude: 33.6875431, longitude: -95.4431142, options: { types: address, limit: 3 } },
             *   function(err, res) {
             *   // res is a GeoJSON document with up to 3 geocoding matches
             * });
             */
            MapboxGeocoding.prototype.geocodeReverse = function(location, options, callback) {

                // permit the options argument to be omitted
                if (callback === undefined && typeof options === 'function') {
                    callback = options;
                    options = {};
                }

                // typecheck arguments
                invariant(typeof location === 'object', 'location must be an object');
                invariant(typeof options === 'object', 'options must be an object');

                invariant(typeof location.latitude === 'number' &&
                    typeof location.longitude === 'number',
                    'location must be an object with numeric latitude & longitude properties');

                var queryOptions = {
                    dataset: 'mapbox.places'
                };

                if (options.dataset) {
                    invariant(typeof options.dataset === 'string', 'dataset option must be string');
                    queryOptions.dataset = options.dataset;
                }

                var precision = REVERSE_GEOCODING_PRECISION;
                if (options.precision) {
                    invariant(typeof options.precision === 'number', 'precision option must be number');
                    precision = options.precision;
                }

                if (options.types) {
                    invariant(typeof options.types === 'string', 'types option must be string');
                    queryOptions.types = options.types;
                }

                if (options.limit) {
                    invariant(typeof options.limit === 'number', 'limit option must be a number');
                    invariant(options.types.split(',').length === 1, 'a single type must be specified to use the limit option');
                    queryOptions.limit = options.limit;
                }

                queryOptions.longitude = roundTo(location.longitude, precision);
                queryOptions.latitude = roundTo(location.latitude, precision);

                return this.client({
                    path: constants.API_GEOCODING_REVERSE,
                    params: queryOptions,
                    callback: callback
                });
            };

            module.exports = MapboxGeocoding;

        }, {
            "../../vendor/invariant": 41,
            "../constants": 8,
            "../make_service": 10
        }],
        12: [function(require, module, exports) {
            var interceptor = require('rest/interceptor');

            var standardResponse = interceptor({
                response: transform,
            });

            function transform(response) {
                return {
                    url: response.url,
                    status: response.status ? response.status.code : undefined,
                    headers: response.headers,
                    entity: response.entity,
                    error: response.error,
                    callback: response.request.callback
                };
            };

            module.exports = standardResponse;

        }, {
            "rest/interceptor": 18
        }],
        13: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var mixin, xWWWFormURLEncoder, origin, urlRE, absoluteUrlRE, fullyQualifiedUrlRE;

            mixin = require('./util/mixin');
            xWWWFormURLEncoder = require('./mime/type/application/x-www-form-urlencoded');

            urlRE = /([a-z][a-z0-9\+\-\.]*:)\/\/([^@]+@)?(([^:\/]+)(:([0-9]+))?)?(\/[^?#]*)?(\?[^#]*)?(#\S*)?/i;
            absoluteUrlRE = /^([a-z][a-z0-9\-\+\.]*:\/\/|\/)/i;
            fullyQualifiedUrlRE = /([a-z][a-z0-9\+\-\.]*:)\/\/([^@]+@)?(([^:\/]+)(:([0-9]+))?)?\//i;

            /**
             * Apply params to the template to create a URL.
             *
             * Parameters that are not applied directly to the template, are appended
             * to the URL as query string parameters.
             *
             * @param {string} template the URI template
             * @param {Object} params parameters to apply to the template
             * @return {string} the resulting URL
             */
            function buildUrl(template, params) {
                // internal builder to convert template with params.
                var url, name, queryStringParams, queryString, re;

                url = template;
                queryStringParams = {};

                if (params) {
                    for (name in params) {
                        /*jshint forin:false */
                        re = new RegExp('\\{' + name + '\\}');
                        if (re.test(url)) {
                            url = url.replace(re, encodeURIComponent(params[name]), 'g');
                        } else {
                            queryStringParams[name] = params[name];
                        }
                    }

                    queryString = xWWWFormURLEncoder.write(queryStringParams);
                    if (queryString) {
                        url += url.indexOf('?') === -1 ? '?' : '&';
                        url += queryString;
                    }
                }
                return url;
            }

            function startsWith(str, test) {
                return str.indexOf(test) === 0;
            }

            /**
             * Create a new URL Builder
             *
             * @param {string|UrlBuilder} template the base template to build from, may be another UrlBuilder
             * @param {Object} [params] base parameters
             * @constructor
             */
            function UrlBuilder(template, params) {
                if (!(this instanceof UrlBuilder)) {
                    // invoke as a constructor
                    return new UrlBuilder(template, params);
                }

                if (template instanceof UrlBuilder) {
                    this._template = template.template;
                    this._params = mixin({}, this._params, params);
                } else {
                    this._template = (template || '').toString();
                    this._params = params || {};
                }
            }

            UrlBuilder.prototype = {

                /**
                 * Create a new UrlBuilder instance that extends the current builder.
                 * The current builder is unmodified.
                 *
                 * @param {string} [template] URL template to append to the current template
                 * @param {Object} [params] params to combine with current params.  New params override existing params
                 * @return {UrlBuilder} the new builder
                 */
                append: function(template, params) {
                    // TODO consider query strings and fragments
                    return new UrlBuilder(this._template + template, mixin({}, this._params, params));
                },

                /**
                 * Create a new UrlBuilder with a fully qualified URL based on the
                 * window's location or base href and the current templates relative URL.
                 *
                 * Path variables are preserved.
                 *
                 * *Browser only*
                 *
                 * @return {UrlBuilder} the fully qualified URL template
                 */
                fullyQualify: function() {
                    if (typeof location === 'undefined') {
                        return this;
                    }
                    if (this.isFullyQualified()) {
                        return this;
                    }

                    var template = this._template;

                    if (startsWith(template, '//')) {
                        template = origin.protocol + template;
                    } else if (startsWith(template, '/')) {
                        template = origin.origin + template;
                    } else if (!this.isAbsolute()) {
                        template = origin.origin + origin.pathname.substring(0, origin.pathname.lastIndexOf('/') + 1);
                    }

                    if (template.indexOf('/', 8) === -1) {
                        // default the pathname to '/'
                        template = template + '/';
                    }

                    return new UrlBuilder(template, this._params);
                },

                /**
                 * True if the URL is absolute
                 *
                 * @return {boolean}
                 */
                isAbsolute: function() {
                    return absoluteUrlRE.test(this.build());
                },

                /**
                 * True if the URL is fully qualified
                 *
                 * @return {boolean}
                 */
                isFullyQualified: function() {
                    return fullyQualifiedUrlRE.test(this.build());
                },

                /**
                 * True if the URL is cross origin. The protocol, host and port must not be
                 * the same in order to be cross origin,
                 *
                 * @return {boolean}
                 */
                isCrossOrigin: function() {
                    if (!origin) {
                        return true;
                    }
                    var url = this.parts();
                    return url.protocol !== origin.protocol ||
                        url.hostname !== origin.hostname ||
                        url.port !== origin.port;
                },

                /**
                 * Split a URL into its consituent parts following the naming convention of
                 * 'window.location'. One difference is that the port will contain the
                 * protocol default if not specified.
                 *
                 * @see https://developer.mozilla.org/en-US/docs/DOM/window.location
                 *
                 * @returns {Object} a 'window.location'-like object
                 */
                parts: function() {
                    /*jshint maxcomplexity:20 */
                    var url, parts;
                    url = this.fullyQualify().build().match(urlRE);
                    parts = {
                        href: url[0],
                        protocol: url[1],
                        host: url[3] || '',
                        hostname: url[4] || '',
                        port: url[6],
                        pathname: url[7] || '',
                        search: url[8] || '',
                        hash: url[9] || ''
                    };
                    parts.origin = parts.protocol + '//' + parts.host;
                    parts.port = parts.port || (parts.protocol === 'https:' ? '443' : parts.protocol === 'http:' ? '80' : '');
                    return parts;
                },

                /**
                 * Expand the template replacing path variables with parameters
                 *
                 * @param {Object} [params] params to combine with current params.  New params override existing params
                 * @return {string} the expanded URL
                 */
                build: function(params) {
                    return buildUrl(this._template, mixin({}, this._params, params));
                },

                /**
                 * @see build
                 */
                toString: function() {
                    return this.build();
                }

            };

            origin = typeof location !== 'undefined' ? new UrlBuilder(location.href).parts() : void 0;

            module.exports = UrlBuilder;

        }, {
            "./mime/type/application/x-www-form-urlencoded": 29,
            "./util/mixin": 36
        }],
        14: [function(require, module, exports) {
            /*
             * Copyright 2014-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var rest = require('./client/default'),
                browser = require('./client/xhr');

            rest.setPlatformDefaultClient(browser);

            module.exports = rest;

        }, {
            "./client/default": 16,
            "./client/xhr": 17
        }],
        15: [function(require, module, exports) {
            /*
             * Copyright 2014-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            /**
             * Add common helper methods to a client impl
             *
             * @param {function} impl the client implementation
             * @param {Client} [target] target of this client, used when wrapping other clients
             * @returns {Client} the client impl with additional methods
             */
            module.exports = function client(impl, target) {

                if (target) {

                    /**
                     * @returns {Client} the target client
                     */
                    impl.skip = function skip() {
                        return target;
                    };

                }

                /**
                 * Allow a client to easily be wrapped by an interceptor
                 *
                 * @param {Interceptor} interceptor the interceptor to wrap this client with
                 * @param [config] configuration for the interceptor
                 * @returns {Client} the newly wrapped client
                 */
                impl.wrap = function wrap(interceptor, config) {
                    return interceptor(impl, config);
                };

                /**
                 * @deprecated
                 */
                impl.chain = function chain() {
                    if (typeof console !== 'undefined') {
                        console.log('rest.js: client.chain() is deprecated, use client.wrap() instead');
                    }

                    return impl.wrap.apply(this, arguments);
                };

                return impl;

            };

        }, {}],
        16: [function(require, module, exports) {
            /*
             * Copyright 2014-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            /**
             * Plain JS Object containing properties that represent an HTTP request.
             *
             * Depending on the capabilities of the underlying client, a request
             * may be cancelable. If a request may be canceled, the client will add
             * a canceled flag and cancel function to the request object. Canceling
             * the request will put the response into an error state.
             *
             * @field {string} [method='GET'] HTTP method, commonly GET, POST, PUT, DELETE or HEAD
             * @field {string|UrlBuilder} [path=''] path template with optional path variables
             * @field {Object} [params] parameters for the path template and query string
             * @field {Object} [headers] custom HTTP headers to send, in addition to the clients default headers
             * @field [entity] the HTTP entity, common for POST or PUT requests
             * @field {boolean} [canceled] true if the request has been canceled, set by the client
             * @field {Function} [cancel] cancels the request if invoked, provided by the client
             * @field {Client} [originator] the client that first handled this request, provided by the interceptor
             *
             * @class Request
             */

            /**
             * Plain JS Object containing properties that represent an HTTP response
             *
             * @field {Object} [request] the request object as received by the root client
             * @field {Object} [raw] the underlying request object, like XmlHttpRequest in a browser
             * @field {number} [status.code] status code of the response (i.e. 200, 404)
             * @field {string} [status.text] status phrase of the response
             * @field {Object] [headers] response headers hash of normalized name, value pairs
             * @field [entity] the response body
             *
             * @class Response
             */

            /**
             * HTTP client particularly suited for RESTful operations.
             *
             * @field {function} wrap wraps this client with a new interceptor returning the wrapped client
             *
             * @param {Request} the HTTP request
             * @returns {ResponsePromise<Response>} a promise the resolves to the HTTP response
             *
             * @class Client
             */

            /**
             * Extended when.js Promises/A+ promise with HTTP specific helpers
             *q
             * @method entity promise for the HTTP entity
             * @method status promise for the HTTP status code
             * @method headers promise for the HTTP response headers
             * @method header promise for a specific HTTP response header
             *
             * @class ResponsePromise
             * @extends Promise
             */

            var client, target, platformDefault;

            client = require('../client');

            if (typeof Promise !== 'function' && console && console.log) {
                console.log('An ES6 Promise implementation is required to use rest.js. See https://github.com/cujojs/when/blob/master/docs/es6-promise-shim.md for using when.js as a Promise polyfill.');
            }

            /**
             * Make a request with the default client
             * @param {Request} the HTTP request
             * @returns {Promise<Response>} a promise the resolves to the HTTP response
             */
            function defaultClient() {
                return target.apply(void 0, arguments);
            }

            /**
             * Change the default client
             * @param {Client} client the new default client
             */
            defaultClient.setDefaultClient = function setDefaultClient(client) {
                target = client;
            };

            /**
             * Obtain a direct reference to the current default client
             * @returns {Client} the default client
             */
            defaultClient.getDefaultClient = function getDefaultClient() {
                return target;
            };

            /**
             * Reset the default client to the platform default
             */
            defaultClient.resetDefaultClient = function resetDefaultClient() {
                target = platformDefault;
            };

            /**
             * @private
             */
            defaultClient.setPlatformDefaultClient = function setPlatformDefaultClient(client) {
                if (platformDefault) {
                    throw new Error('Unable to redefine platformDefaultClient');
                }
                target = platformDefault = client;
            };

            module.exports = client(defaultClient);

        }, {
            "../client": 15
        }],
        17: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var normalizeHeaderName, responsePromise, client, headerSplitRE;

            normalizeHeaderName = require('../util/normalizeHeaderName');
            responsePromise = require('../util/responsePromise');
            client = require('../client');

            // according to the spec, the line break is '\r\n', but doesn't hold true in practice
            headerSplitRE = /[\r|\n]+/;

            function parseHeaders(raw) {
                // Note: Set-Cookie will be removed by the browser
                var headers = {};

                if (!raw) {
                    return headers;
                }

                raw.trim().split(headerSplitRE).forEach(function(header) {
                    var boundary, name, value;
                    boundary = header.indexOf(':');
                    name = normalizeHeaderName(header.substring(0, boundary).trim());
                    value = header.substring(boundary + 1).trim();
                    if (headers[name]) {
                        if (Array.isArray(headers[name])) {
                            // add to an existing array
                            headers[name].push(value);
                        } else {
                            // convert single value to array
                            headers[name] = [headers[name], value];
                        }
                    } else {
                        // new, single value
                        headers[name] = value;
                    }
                });

                return headers;
            }

            function safeMixin(target, source) {
                Object.keys(source || {}).forEach(function(prop) {
                    // make sure the property already exists as
                    // IE 6 will blow up if we add a new prop
                    if (source.hasOwnProperty(prop) && prop in target) {
                        try {
                            target[prop] = source[prop];
                        } catch (e) {
                            // ignore, expected for some properties at some points in the request lifecycle
                        }
                    }
                });

                return target;
            }

            module.exports = client(function xhr(request) {
                return responsePromise.promise(function(resolve, reject) {
                    /*jshint maxcomplexity:20 */

                    var client, method, url, headers, entity, headerName, response, XHR;

                    request = typeof request === 'string' ? {
                        path: request
                    } : request || {};
                    response = {
                        request: request
                    };

                    if (request.canceled) {
                        response.error = 'precanceled';
                        reject(response);
                        return;
                    }

                    XHR = request.engine || XMLHttpRequest;
                    if (!XHR) {
                        reject({
                            request: request,
                            error: 'xhr-not-available'
                        });
                        return;
                    }

                    entity = request.entity;
                    request.method = request.method || (entity ? 'POST' : 'GET');
                    method = request.method;
                    url = response.url = request.path || '';

                    try {
                        client = response.raw = new XHR();

                        // mixin extra request properties before and after opening the request as some properties require being set at different phases of the request
                        safeMixin(client, request.mixin);
                        client.open(method, url, true);
                        safeMixin(client, request.mixin);

                        headers = request.headers;
                        for (headerName in headers) {
                            /*jshint forin:false */
                            if (headerName === 'Content-Type' && headers[headerName] === 'multipart/form-data') {
                                // XMLHttpRequest generates its own Content-Type header with the
                                // appropriate multipart boundary when sending multipart/form-data.
                                continue;
                            }

                            client.setRequestHeader(headerName, headers[headerName]);
                        }

                        request.canceled = false;
                        request.cancel = function cancel() {
                            request.canceled = true;
                            client.abort();
                            reject(response);
                        };

                        client.onreadystatechange = function( /* e */ ) {
                            if (request.canceled) {
                                return;
                            }
                            if (client.readyState === (XHR.DONE || 4)) {
                                response.status = {
                                    code: client.status,
                                    text: client.statusText
                                };
                                response.headers = parseHeaders(client.getAllResponseHeaders());
                                response.entity = client.responseText;

                                // #125 -- Sometimes IE8-9 uses 1223 instead of 204
                                // http://stackoverflow.com/questions/10046972/msie-returns-status-code-of-1223-for-ajax-request
                                if (response.status.code === 1223) {
                                    response.status.code = 204;
                                }

                                if (response.status.code > 0) {
                                    // check status code as readystatechange fires before error event
                                    resolve(response);
                                } else {
                                    // give the error callback a chance to fire before resolving
                                    // requests for file:// URLs do not have a status code
                                    setTimeout(function() {
                                        resolve(response);
                                    }, 0);
                                }
                            }
                        };

                        try {
                            client.onerror = function( /* e */ ) {
                                response.error = 'loaderror';
                                reject(response);
                            };
                        } catch (e) {
                            // IE 6 will not support error handling
                        }

                        client.send(entity);
                    } catch (e) {
                        response.error = 'loaderror';
                        reject(response);
                    }

                });
            });

        }, {
            "../client": 15,
            "../util/normalizeHeaderName": 37,
            "../util/responsePromise": 38
        }],
        18: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var defaultClient, mixin, responsePromise, client;

            defaultClient = require('./client/default');
            mixin = require('./util/mixin');
            responsePromise = require('./util/responsePromise');
            client = require('./client');

            /**
             * Interceptors have the ability to intercept the request and/org response
             * objects.  They may augment, prune, transform or replace the
             * request/response as needed.  Clients may be composed by wrapping
             * together multiple interceptors.
             *
             * Configured interceptors are functional in nature.  Wrapping a client in
             * an interceptor will not affect the client, merely the data that flows in
             * and out of that client.  A common configuration can be created once and
             * shared; specialization can be created by further wrapping that client
             * with custom interceptors.
             *
             * @param {Client} [target] client to wrap
             * @param {Object} [config] configuration for the interceptor, properties will be specific to the interceptor implementation
             * @returns {Client} A client wrapped with the interceptor
             *
             * @class Interceptor
             */

            function defaultInitHandler(config) {
                return config;
            }

            function defaultRequestHandler(request /*, config, meta */ ) {
                return request;
            }

            function defaultResponseHandler(response /*, config, meta */ ) {
                return response;
            }

            /**
             * Alternate return type for the request handler that allows for more complex interactions.
             *
             * @param properties.request the traditional request return object
             * @param {Promise} [properties.abort] promise that resolves if/when the request is aborted
             * @param {Client} [properties.client] override the defined client with an alternate client
             * @param [properties.response] response for the request, short circuit the request
             */
            function ComplexRequest(properties) {
                if (!(this instanceof ComplexRequest)) {
                    // in case users forget the 'new' don't mix into the interceptor
                    return new ComplexRequest(properties);
                }
                mixin(this, properties);
            }

            /**
             * Create a new interceptor for the provided handlers.
             *
             * @param {Function} [handlers.init] one time intialization, must return the config object
             * @param {Function} [handlers.request] request handler
             * @param {Function} [handlers.response] response handler regardless of error state
             * @param {Function} [handlers.success] response handler when the request is not in error
             * @param {Function} [handlers.error] response handler when the request is in error, may be used to 'unreject' an error state
             * @param {Function} [handlers.client] the client to use if otherwise not specified, defaults to platform default client
             *
             * @returns {Interceptor}
             */
            function interceptor(handlers) {

                var initHandler, requestHandler, successResponseHandler, errorResponseHandler;

                handlers = handlers || {};

                initHandler = handlers.init || defaultInitHandler;
                requestHandler = handlers.request || defaultRequestHandler;
                successResponseHandler = handlers.success || handlers.response || defaultResponseHandler;
                errorResponseHandler = handlers.error || function() {
                    // Propagate the rejection, with the result of the handler
                    return Promise.resolve((handlers.response || defaultResponseHandler).apply(this, arguments))
                        .then(Promise.reject.bind(Promise));
                };

                return function(target, config) {

                    if (typeof target === 'object') {
                        config = target;
                    }
                    if (typeof target !== 'function') {
                        target = handlers.client || defaultClient;
                    }

                    config = initHandler(config || {});

                    function interceptedClient(request) {
                        var context, meta;
                        context = {};
                        meta = {
                            'arguments': Array.prototype.slice.call(arguments),
                            client: interceptedClient
                        };
                        request = typeof request === 'string' ? {
                            path: request
                        } : request || {};
                        request.originator = request.originator || interceptedClient;
                        return responsePromise(
                            requestHandler.call(context, request, config, meta),
                            function(request) {
                                var response, abort, next;
                                next = target;
                                if (request instanceof ComplexRequest) {
                                    // unpack request
                                    abort = request.abort;
                                    next = request.client || next;
                                    response = request.response;
                                    // normalize request, must be last
                                    request = request.request;
                                }
                                response = response || Promise.resolve(request).then(function(request) {
                                    return Promise.resolve(next(request)).then(
                                        function(response) {
                                            return successResponseHandler.call(context, response, config, meta);
                                        },
                                        function(response) {
                                            return errorResponseHandler.call(context, response, config, meta);
                                        }
                                    );
                                });
                                return abort ? Promise.race([response, abort]) : response;
                            },
                            function(error) {
                                return Promise.reject({
                                    request: request,
                                    error: error
                                });
                            }
                        );
                    }

                    return client(interceptedClient, target);
                };
            }

            interceptor.ComplexRequest = ComplexRequest;

            module.exports = interceptor;

        }, {
            "./client": 15,
            "./client/default": 16,
            "./util/mixin": 36,
            "./util/responsePromise": 38
        }],
        19: [function(require, module, exports) {
            /*
             * Copyright 2013-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var interceptor, mixinUtil, defaulter;

            interceptor = require('../interceptor');
            mixinUtil = require('../util/mixin');

            defaulter = (function() {

                function mixin(prop, target, defaults) {
                    if (prop in target || prop in defaults) {
                        target[prop] = mixinUtil({}, defaults[prop], target[prop]);
                    }
                }

                function copy(prop, target, defaults) {
                    if (prop in defaults && !(prop in target)) {
                        target[prop] = defaults[prop];
                    }
                }

                var mappings = {
                    method: copy,
                    path: copy,
                    params: mixin,
                    headers: mixin,
                    entity: copy,
                    mixin: mixin
                };

                return function(target, defaults) {
                    for (var prop in mappings) {
                        /*jshint forin: false */
                        mappings[prop](prop, target, defaults);
                    }
                    return target;
                };

            }());

            /**
             * Provide default values for a request. These values will be applied to the
             * request if the request object does not already contain an explicit value.
             *
             * For 'params', 'headers', and 'mixin', individual values are mixed in with the
             * request's values. The result is a new object representiing the combined
             * request and config values. Neither input object is mutated.
             *
             * @param {Client} [client] client to wrap
             * @param {string} [config.method] the default method
             * @param {string} [config.path] the default path
             * @param {Object} [config.params] the default params, mixed with the request's existing params
             * @param {Object} [config.headers] the default headers, mixed with the request's existing headers
             * @param {Object} [config.mixin] the default "mixins" (http/https options), mixed with the request's existing "mixins"
             *
             * @returns {Client}
             */
            module.exports = interceptor({
                request: function handleRequest(request, config) {
                    return defaulter(request, config);
                }
            });

        }, {
            "../interceptor": 18,
            "../util/mixin": 36
        }],
        20: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var interceptor;

            interceptor = require('../interceptor');

            /**
             * Rejects the response promise based on the status code.
             *
             * Codes greater than or equal to the provided value are rejected.  Default
             * value 400.
             *
             * @param {Client} [client] client to wrap
             * @param {number} [config.code=400] code to indicate a rejection
             *
             * @returns {Client}
             */
            module.exports = interceptor({
                init: function(config) {
                    config.code = config.code || 400;
                    return config;
                },
                response: function(response, config) {
                    if (response.status && response.status.code >= config.code) {
                        return Promise.reject(response);
                    }
                    return response;
                }
            });

        }, {
            "../interceptor": 18
        }],
        21: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var interceptor, mime, registry, noopConverter, missingConverter, attempt;

            interceptor = require('../interceptor');
            mime = require('../mime');
            registry = require('../mime/registry');
            attempt = require('../util/attempt');

            noopConverter = {
                read: function(obj) {
                    return obj;
                },
                write: function(obj) {
                    return obj;
                }
            };

            missingConverter = {
                read: function() {
                    throw 'No read method found on converter';
                },
                write: function() {
                    throw 'No write method found on converter';
                }
            };

            /**
             * MIME type support for request and response entities.  Entities are
             * (de)serialized using the converter for the MIME type.
             *
             * Request entities are converted using the desired converter and the
             * 'Accept' request header prefers this MIME.
             *
             * Response entities are converted based on the Content-Type response header.
             *
             * @param {Client} [client] client to wrap
             * @param {string} [config.mime='text/plain'] MIME type to encode the request
             *   entity
             * @param {string} [config.accept] Accept header for the request
             * @param {Client} [config.client=<request.originator>] client passed to the
             *   converter, defaults to the client originating the request
             * @param {Registry} [config.registry] MIME registry, defaults to the root
             *   registry
             * @param {boolean} [config.permissive] Allow an unkown request MIME type
             *
             * @returns {Client}
             */
            module.exports = interceptor({
                init: function(config) {
                    config.registry = config.registry || registry;
                    return config;
                },
                request: function(request, config) {
                    var type, headers;

                    headers = request.headers || (request.headers = {});
                    type = mime.parse(headers['Content-Type'] || config.mime || 'text/plain');
                    headers.Accept = headers.Accept || config.accept || type.raw + ', application/json;q=0.8, text/plain;q=0.5, */*;q=0.2';

                    if (!('entity' in request)) {
                        return request;
                    }

                    headers['Content-Type'] = type.raw;

                    return config.registry.lookup(type)['catch'](function() {
                        // failed to resolve converter
                        if (config.permissive) {
                            return noopConverter;
                        }
                        throw 'mime-unknown';
                    }).then(function(converter) {
                        var client = config.client || request.originator,
                            write = converter.write || missingConverter.write;

                        return attempt(write.bind(void 0, request.entity, {
                                client: client,
                                request: request,
                                mime: type,
                                registry: config.registry
                            }))['catch'](function() {
                                throw 'mime-serialization';
                            })
                            .then(function(entity) {
                                request.entity = entity;
                                return request;
                            });
                    });
                },
                response: function(response, config) {
                    if (!(response.headers && response.headers['Content-Type'] && response.entity)) {
                        return response;
                    }

                    var type = mime.parse(response.headers['Content-Type']);

                    return config.registry.lookup(type)['catch'](function() {
                        return noopConverter;
                    }).then(function(converter) {
                        var client = config.client || response.request && response.request.originator,
                            read = converter.read || missingConverter.read;

                        return attempt(read.bind(void 0, response.entity, {
                                client: client,
                                response: response,
                                mime: type,
                                registry: config.registry
                            }))['catch'](function(e) {
                                response.error = 'mime-deserialization';
                                response.cause = e;
                                throw response;
                            })
                            .then(function(entity) {
                                response.entity = entity;
                                return response;
                            });
                    });
                }
            });

        }, {
            "../interceptor": 18,
            "../mime": 25,
            "../mime/registry": 26,
            "../util/attempt": 32
        }],
        22: [function(require, module, exports) {
            /*
             * Copyright 2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var interceptor, UrlBuilder;

            interceptor = require('../interceptor');
            UrlBuilder = require('../UrlBuilder');

            /**
             * Applies request params to the path by token replacement
             *
             * Params not applied as a token are appended to the query string. Params
             * are removed from the request object, as they have been consumed.
             *
             * @deprecated The template interceptor `rest/interceptor/template` is a
             * much richer way to apply paramters to a template. This interceptor is
             * available as a bridge to users who previousled depended on this
             * functionality being available directly on clients.
             *
             * @param {Client} [client] client to wrap
             * @param {Object} [config.params] default param values
             *
             * @returns {Client}
             */
            module.exports = interceptor({
                init: function(config) {
                    config.params = config.params || {};
                    return config;
                },
                request: function(request, config) {
                    var path, params;

                    path = request.path || '';
                    params = request.params || {};

                    request.path = new UrlBuilder(path, config.params).append('', params).build();
                    delete request.params;

                    return request;
                }
            });

        }, {
            "../UrlBuilder": 13,
            "../interceptor": 18
        }],
        23: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var interceptor, UrlBuilder;

            interceptor = require('../interceptor');
            UrlBuilder = require('../UrlBuilder');

            function startsWith(str, prefix) {
                return str.indexOf(prefix) === 0;
            }

            function endsWith(str, suffix) {
                return str.lastIndexOf(suffix) + suffix.length === str.length;
            }

            /**
             * Prefixes the request path with a common value.
             *
             * @param {Client} [client] client to wrap
             * @param {number} [config.prefix] path prefix
             *
             * @returns {Client}
             */
            module.exports = interceptor({
                request: function(request, config) {
                    var path;

                    if (config.prefix && !(new UrlBuilder(request.path).isFullyQualified())) {
                        path = config.prefix;
                        if (request.path) {
                            if (!endsWith(path, '/') && !startsWith(request.path, '/')) {
                                // add missing '/' between path sections
                                path += '/';
                            }
                            path += request.path;
                        }
                        request.path = path;
                    }

                    return request;
                }
            });

        }, {
            "../UrlBuilder": 13,
            "../interceptor": 18
        }],
        24: [function(require, module, exports) {
            /*
             * Copyright 2015-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var interceptor, uriTemplate, mixin;

            interceptor = require('../interceptor');
            uriTemplate = require('../util/uriTemplate');
            mixin = require('../util/mixin');

            /**
             * Applies request params to the path as a URI Template
             *
             * Params are removed from the request object, as they have been consumed.
             *
             * @see https://tools.ietf.org/html/rfc6570
             *
             * @param {Client} [client] client to wrap
             * @param {Object} [config.params] default param values
             * @param {string} [config.template] default template
             *
             * @returns {Client}
             */
            module.exports = interceptor({
                init: function(config) {
                    config.params = config.params || {};
                    config.template = config.template || '';
                    return config;
                },
                request: function(request, config) {
                    var template, params;

                    template = request.path || config.template;
                    params = mixin({}, request.params, config.params);

                    request.path = uriTemplate.expand(template, params);
                    delete request.params;

                    return request;
                }
            });

        }, {
            "../interceptor": 18,
            "../util/mixin": 36,
            "../util/uriTemplate": 40
        }],
        25: [function(require, module, exports) {
            /*
             * Copyright 2014-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            /**
             * Parse a MIME type into it's constituent parts
             *
             * @param {string} mime MIME type to parse
             * @return {{
             *   {string} raw the original MIME type
             *   {string} type the type and subtype
             *   {string} [suffix] mime suffix, including the plus, if any
             *   {Object} params key/value pair of attributes
             * }}
             */
            function parse(mime) {
                var params, type;

                params = mime.split(';');
                type = params[0].trim().split('+');

                return {
                    raw: mime,
                    type: type[0],
                    suffix: type[1] ? '+' + type[1] : '',
                    params: params.slice(1).reduce(function(params, pair) {
                        pair = pair.split('=');
                        params[pair[0].trim()] = pair[1] ? pair[1].trim() : void 0;
                        return params;
                    }, {})
                };
            }

            module.exports = {
                parse: parse
            };

        }, {}],
        26: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var mime, registry;

            mime = require('../mime');

            function Registry(mimes) {

                /**
                 * Lookup the converter for a MIME type
                 *
                 * @param {string} type the MIME type
                 * @return a promise for the converter
                 */
                this.lookup = function lookup(type) {
                    var parsed;

                    parsed = typeof type === 'string' ? mime.parse(type) : type;

                    if (mimes[parsed.raw]) {
                        return mimes[parsed.raw];
                    }
                    if (mimes[parsed.type + parsed.suffix]) {
                        return mimes[parsed.type + parsed.suffix];
                    }
                    if (mimes[parsed.type]) {
                        return mimes[parsed.type];
                    }
                    if (mimes[parsed.suffix]) {
                        return mimes[parsed.suffix];
                    }

                    return Promise.reject(new Error('Unable to locate converter for mime "' + parsed.raw + '"'));
                };

                /**
                 * Create a late dispatched proxy to the target converter.
                 *
                 * Common when a converter is registered under multiple names and
                 * should be kept in sync if updated.
                 *
                 * @param {string} type mime converter to dispatch to
                 * @returns converter whose read/write methods target the desired mime converter
                 */
                this.delegate = function delegate(type) {
                    return {
                        read: function() {
                            var args = arguments;
                            return this.lookup(type).then(function(converter) {
                                return converter.read.apply(this, args);
                            }.bind(this));
                        }.bind(this),
                        write: function() {
                            var args = arguments;
                            return this.lookup(type).then(function(converter) {
                                return converter.write.apply(this, args);
                            }.bind(this));
                        }.bind(this)
                    };
                };

                /**
                 * Register a custom converter for a MIME type
                 *
                 * @param {string} type the MIME type
                 * @param converter the converter for the MIME type
                 * @return a promise for the converter
                 */
                this.register = function register(type, converter) {
                    mimes[type] = Promise.resolve(converter);
                    return mimes[type];
                };

                /**
                 * Create a child registry whoes registered converters remain local, while
                 * able to lookup converters from its parent.
                 *
                 * @returns child MIME registry
                 */
                this.child = function child() {
                    return new Registry(Object.create(mimes));
                };

            }

            registry = new Registry({});

            // include provided serializers
            registry.register('application/hal', require('./type/application/hal'));
            registry.register('application/json', require('./type/application/json'));
            registry.register('application/x-www-form-urlencoded', require('./type/application/x-www-form-urlencoded'));
            registry.register('multipart/form-data', require('./type/multipart/form-data'));
            registry.register('text/plain', require('./type/text/plain'));

            registry.register('+json', registry.delegate('application/json'));

            module.exports = registry;

        }, {
            "../mime": 25,
            "./type/application/hal": 27,
            "./type/application/json": 28,
            "./type/application/x-www-form-urlencoded": 29,
            "./type/multipart/form-data": 30,
            "./type/text/plain": 31
        }],
        27: [function(require, module, exports) {
            /*
             * Copyright 2013-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var pathPrefix, template, find, lazyPromise, responsePromise;

            pathPrefix = require('../../../interceptor/pathPrefix');
            template = require('../../../interceptor/template');
            find = require('../../../util/find');
            lazyPromise = require('../../../util/lazyPromise');
            responsePromise = require('../../../util/responsePromise');

            function defineProperty(obj, name, value) {
                Object.defineProperty(obj, name, {
                    value: value,
                    configurable: true,
                    enumerable: false,
                    writeable: true
                });
            }

            /**
             * Hypertext Application Language serializer
             *
             * Implemented to https://tools.ietf.org/html/draft-kelly-json-hal-06
             *
             * As the spec is still a draft, this implementation will be updated as the
             * spec evolves
             *
             * Objects are read as HAL indexing links and embedded objects on to the
             * resource. Objects are written as plain JSON.
             *
             * Embedded relationships are indexed onto the resource by the relationship
             * as a promise for the related resource.
             *
             * Links are indexed onto the resource as a lazy promise that will GET the
             * resource when a handler is first registered on the promise.
             *
             * A `requestFor` method is added to the entity to make a request for the
             * relationship.
             *
             * A `clientFor` method is added to the entity to get a full Client for a
             * relationship.
             *
             * The `_links` and `_embedded` properties on the resource are made
             * non-enumerable.
             */
            module.exports = {

                read: function(str, opts) {
                    var client, console;

                    opts = opts || {};
                    client = opts.client;
                    console = opts.console || console;

                    function deprecationWarning(relationship, deprecation) {
                        if (deprecation && console && console.warn || console.log) {
                            (console.warn || console.log).call(console, 'Relationship \'' + relationship + '\' is deprecated, see ' + deprecation);
                        }
                    }

                    return opts.registry.lookup(opts.mime.suffix).then(function(converter) {
                        return converter.read(str, opts);
                    }).then(function(root) {
                        find.findProperties(root, '_embedded', function(embedded, resource, name) {
                            Object.keys(embedded).forEach(function(relationship) {
                                if (relationship in resource) {
                                    return;
                                }
                                var related = responsePromise({
                                    entity: embedded[relationship]
                                });
                                defineProperty(resource, relationship, related);
                            });
                            defineProperty(resource, name, embedded);
                        });
                        find.findProperties(root, '_links', function(links, resource, name) {
                            Object.keys(links).forEach(function(relationship) {
                                var link = links[relationship];
                                if (relationship in resource) {
                                    return;
                                }
                                defineProperty(resource, relationship, responsePromise.make(lazyPromise(function() {
                                    if (link.deprecation) {
                                        deprecationWarning(relationship, link.deprecation);
                                    }
                                    if (link.templated === true) {
                                        return template(client)({
                                            path: link.href
                                        });
                                    }
                                    return client({
                                        path: link.href
                                    });
                                })));
                            });
                            defineProperty(resource, name, links);
                            defineProperty(resource, 'clientFor', function(relationship, clientOverride) {
                                var link = links[relationship];
                                if (!link) {
                                    throw new Error('Unknown relationship: ' + relationship);
                                }
                                if (link.deprecation) {
                                    deprecationWarning(relationship, link.deprecation);
                                }
                                if (link.templated === true) {
                                    return template(
                                        clientOverride || client, {
                                            template: link.href
                                        }
                                    );
                                }
                                return pathPrefix(
                                    clientOverride || client, {
                                        prefix: link.href
                                    }
                                );
                            });
                            defineProperty(resource, 'requestFor', function(relationship, request, clientOverride) {
                                var client = this.clientFor(relationship, clientOverride);
                                return client(request);
                            });
                        });

                        return root;
                    });

                },

                write: function(obj, opts) {
                    return opts.registry.lookup(opts.mime.suffix).then(function(converter) {
                        return converter.write(obj, opts);
                    });
                }

            };

        }, {
            "../../../interceptor/pathPrefix": 23,
            "../../../interceptor/template": 24,
            "../../../util/find": 34,
            "../../../util/lazyPromise": 35,
            "../../../util/responsePromise": 38
        }],
        28: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            /**
             * Create a new JSON converter with custom reviver/replacer.
             *
             * The extended converter must be published to a MIME registry in order
             * to be used. The existing converter will not be modified.
             *
             * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON
             *
             * @param {function} [reviver=undefined] custom JSON.parse reviver
             * @param {function|Array} [replacer=undefined] custom JSON.stringify replacer
             */
            function createConverter(reviver, replacer) {
                return {

                    read: function(str) {
                        return JSON.parse(str, reviver);
                    },

                    write: function(obj) {
                        return JSON.stringify(obj, replacer);
                    },

                    extend: createConverter

                };
            }

            module.exports = createConverter();

        }, {}],
        29: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var encodedSpaceRE, urlEncodedSpaceRE;

            encodedSpaceRE = /%20/g;
            urlEncodedSpaceRE = /\+/g;

            function urlEncode(str) {
                str = encodeURIComponent(str);
                // spec says space should be encoded as '+'
                return str.replace(encodedSpaceRE, '+');
            }

            function urlDecode(str) {
                // spec says space should be encoded as '+'
                str = str.replace(urlEncodedSpaceRE, ' ');
                return decodeURIComponent(str);
            }

            function append(str, name, value) {
                if (Array.isArray(value)) {
                    value.forEach(function(value) {
                        str = append(str, name, value);
                    });
                } else {
                    if (str.length > 0) {
                        str += '&';
                    }
                    str += urlEncode(name);
                    if (value !== undefined && value !== null) {
                        str += '=' + urlEncode(value);
                    }
                }
                return str;
            }

            module.exports = {

                read: function(str) {
                    var obj = {};
                    str.split('&').forEach(function(entry) {
                        var pair, name, value;
                        pair = entry.split('=');
                        name = urlDecode(pair[0]);
                        if (pair.length === 2) {
                            value = urlDecode(pair[1]);
                        } else {
                            value = null;
                        }
                        if (name in obj) {
                            if (!Array.isArray(obj[name])) {
                                // convert to an array, perserving currnent value
                                obj[name] = [obj[name]];
                            }
                            obj[name].push(value);
                        } else {
                            obj[name] = value;
                        }
                    });
                    return obj;
                },

                write: function(obj) {
                    var str = '';
                    Object.keys(obj).forEach(function(name) {
                        str = append(str, name, obj[name]);
                    });
                    return str;
                }

            };

        }, {}],
        30: [function(require, module, exports) {
            /*
             * Copyright 2014-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Michael Jackson
             */

            /* global FormData, File, Blob */

            'use strict';

            function isFormElement(object) {
                return object &&
                    object.nodeType === 1 && // Node.ELEMENT_NODE
                    object.tagName === 'FORM';
            }

            function createFormDataFromObject(object) {
                var formData = new FormData();

                var value;
                for (var property in object) {
                    if (object.hasOwnProperty(property)) {
                        value = object[property];

                        if (value instanceof File) {
                            formData.append(property, value, value.name);
                        } else if (value instanceof Blob) {
                            formData.append(property, value);
                        } else {
                            formData.append(property, String(value));
                        }
                    }
                }

                return formData;
            }

            module.exports = {

                write: function(object) {
                    if (typeof FormData === 'undefined') {
                        throw new Error('The multipart/form-data mime serializer requires FormData support');
                    }

                    // Support FormData directly.
                    if (object instanceof FormData) {
                        return object;
                    }

                    // Support <form> elements.
                    if (isFormElement(object)) {
                        return new FormData(object);
                    }

                    // Support plain objects, may contain File/Blob as value.
                    if (typeof object === 'object' && object !== null) {
                        return createFormDataFromObject(object);
                    }

                    throw new Error('Unable to create FormData from object ' + object);
                }

            };

        }, {}],
        31: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            module.exports = {

                read: function(str) {
                    return str;
                },

                write: function(obj) {
                    return obj.toString();
                }

            };

        }, {}],
        32: [function(require, module, exports) {
            /*
             * Copyright 2015-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            /**
             * Attempt to invoke a function capturing the resulting value as a Promise
             *
             * If the method throws, the caught value used to reject the Promise.
             *
             * @param {function} work function to invoke
             * @returns {Promise} Promise for the output of the work function
             */
            function attempt(work) {
                try {
                    return Promise.resolve(work());
                } catch (e) {
                    return Promise.reject(e);
                }
            }

            module.exports = attempt;

        }, {}],
        33: [function(require, module, exports) {
            /*
             * Copyright (c) 2009 Nicholas C. Zakas. All rights reserved.
             *
             * Permission is hereby granted, free of charge, to any person obtaining a copy
             * of this software and associated documentation files (the "Software"), to deal
             * in the Software without restriction, including without limitation the rights
             * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
             * copies of the Software, and to permit persons to whom the Software is
             * furnished to do so, subject to the following conditions:
             *
             * The above copyright notice and this permission notice shall be included in
             * all copies or substantial portions of the Software.
             *
             * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
             * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
             * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
             * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
             * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
             * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
             * THE SOFTWARE.
             */

            /*
             * Base 64 implementation in JavaScript
             * Original source available at https://raw.github.com/nzakas/computer-science-in-javascript/02a2745b4aa8214f2cae1bf0b15b447ca1a91b23/encodings/base64/base64.js
             *
             * Linter refinement by Scott Andrews
             */

            'use strict';

            /*jshint bitwise: false */

            var digits = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

            /**
             * Base64-encodes a string of text.
             *
             * @param {string} text The text to encode.
             * @return {string} The base64-encoded string.
             */
            function base64Encode(text) {

                if (/([^\u0000-\u00ff])/.test(text)) {
                    throw new Error('Can\'t base64 encode non-ASCII characters.');
                }

                var i = 0,
                    cur, prev, byteNum,
                    result = [];

                while (i < text.length) {

                    cur = text.charCodeAt(i);
                    byteNum = i % 3;

                    switch (byteNum) {
                        case 0: //first byte
                            result.push(digits.charAt(cur >> 2));
                            break;

                        case 1: //second byte
                            result.push(digits.charAt((prev & 3) << 4 | (cur >> 4)));
                            break;

                        case 2: //third byte
                            result.push(digits.charAt((prev & 0x0f) << 2 | (cur >> 6)));
                            result.push(digits.charAt(cur & 0x3f));
                            break;
                    }

                    prev = cur;
                    i += 1;
                }

                if (byteNum === 0) {
                    result.push(digits.charAt((prev & 3) << 4));
                    result.push('==');
                } else if (byteNum === 1) {
                    result.push(digits.charAt((prev & 0x0f) << 2));
                    result.push('=');
                }

                return result.join('');
            }

            /**
             * Base64-decodes a string of text.
             *
             * @param {string} text The text to decode.
             * @return {string} The base64-decoded string.
             */
            function base64Decode(text) {

                //ignore white space
                text = text.replace(/\s/g, '');

                //first check for any unexpected input
                if (!(/^[a-z0-9\+\/\s]+\={0,2}$/i.test(text)) || text.length % 4 > 0) {
                    throw new Error('Not a base64-encoded string.');
                }

                //local variables
                var cur, prev, digitNum,
                    i = 0,
                    result = [];

                //remove any equals signs
                text = text.replace(/\=/g, '');

                //loop over each character
                while (i < text.length) {

                    cur = digits.indexOf(text.charAt(i));
                    digitNum = i % 4;

                    switch (digitNum) {

                        //case 0: first digit - do nothing, not enough info to work with

                        case 1: //second digit
                            result.push(String.fromCharCode(prev << 2 | cur >> 4));
                            break;

                        case 2: //third digit
                            result.push(String.fromCharCode((prev & 0x0f) << 4 | cur >> 2));
                            break;

                        case 3: //fourth digit
                            result.push(String.fromCharCode((prev & 3) << 6 | cur));
                            break;
                    }

                    prev = cur;
                    i += 1;
                }

                //return a string
                return result.join('');

            }

            module.exports = {
                encode: base64Encode,
                decode: base64Decode
            };

        }, {}],
        34: [function(require, module, exports) {
            /*
             * Copyright 2013-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            module.exports = {

                /**
                 * Find objects within a graph the contain a property of a certain name.
                 *
                 * NOTE: this method will not discover object graph cycles.
                 *
                 * @param {*} obj object to search on
                 * @param {string} prop name of the property to search for
                 * @param {Function} callback function to receive the found properties and their parent
                 */
                findProperties: function findProperties(obj, prop, callback) {
                    if (typeof obj !== 'object' || obj === null) {
                        return;
                    }
                    if (prop in obj) {
                        callback(obj[prop], obj, prop);
                    }
                    Object.keys(obj).forEach(function(key) {
                        findProperties(obj[key], prop, callback);
                    });
                }

            };

        }, {}],
        35: [function(require, module, exports) {
            /*
             * Copyright 2013-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var attempt = require('./attempt');

            /**
             * Create a promise whose work is started only when a handler is registered.
             *
             * The work function will be invoked at most once. Thrown values will result
             * in promise rejection.
             *
             * @param {Function} work function whose ouput is used to resolve the
             *   returned promise.
             * @returns {Promise} a lazy promise
             */
            function lazyPromise(work) {
                var started, resolver, promise, then;

                started = false;

                promise = new Promise(function(resolve, reject) {
                    resolver = {
                        resolve: resolve,
                        reject: reject
                    };
                });
                then = promise.then;

                promise.then = function() {
                    if (!started) {
                        started = true;
                        attempt(work).then(resolver.resolve, resolver.reject);
                    }
                    return then.apply(promise, arguments);
                };

                return promise;
            }

            module.exports = lazyPromise;

        }, {
            "./attempt": 32
        }],
        36: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var empty = {};

            /**
             * Mix the properties from the source object into the destination object.
             * When the same property occurs in more then one object, the right most
             * value wins.
             *
             * @param {Object} dest the object to copy properties to
             * @param {Object} sources the objects to copy properties from.  May be 1 to N arguments, but not an Array.
             * @return {Object} the destination object
             */
            function mixin(dest /*, sources... */ ) {
                var i, l, source, name;

                if (!dest) {
                    dest = {};
                }
                for (i = 1, l = arguments.length; i < l; i += 1) {
                    source = arguments[i];
                    for (name in source) {
                        if (!(name in dest) || (dest[name] !== source[name] && (!(name in empty) || empty[name] !== source[name]))) {
                            dest[name] = source[name];
                        }
                    }
                }

                return dest; // Object
            }

            module.exports = mixin;

        }, {}],
        37: [function(require, module, exports) {
            /*
             * Copyright 2012-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            /**
             * Normalize HTTP header names using the pseudo camel case.
             *
             * For example:
             *   content-type         -> Content-Type
             *   accepts              -> Accepts
             *   x-custom-header-name -> X-Custom-Header-Name
             *
             * @param {string} name the raw header name
             * @return {string} the normalized header name
             */
            function normalizeHeaderName(name) {
                return name.toLowerCase()
                    .split('-')
                    .map(function(chunk) {
                        return chunk.charAt(0).toUpperCase() + chunk.slice(1);
                    })
                    .join('-');
            }

            module.exports = normalizeHeaderName;

        }, {}],
        38: [function(require, module, exports) {
            /*
             * Copyright 2014-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            /*jshint latedef: nofunc */

            var normalizeHeaderName = require('./normalizeHeaderName');

            function property(promise, name) {
                return promise.then(
                    function(value) {
                        return value && value[name];
                    },
                    function(value) {
                        return Promise.reject(value && value[name]);
                    }
                );
            }

            /**
             * Obtain the response entity
             *
             * @returns {Promise} for the response entity
             */
            function entity() {
                /*jshint validthis:true */
                return property(this, 'entity');
            }

            /**
             * Obtain the response status
             *
             * @returns {Promise} for the response status
             */
            function status() {
                /*jshint validthis:true */
                return property(property(this, 'status'), 'code');
            }

            /**
             * Obtain the response headers map
             *
             * @returns {Promise} for the response headers map
             */
            function headers() {
                /*jshint validthis:true */
                return property(this, 'headers');
            }

            /**
             * Obtain a specific response header
             *
             * @param {String} headerName the header to retrieve
             * @returns {Promise} for the response header's value
             */
            function header(headerName) {
                /*jshint validthis:true */
                headerName = normalizeHeaderName(headerName);
                return property(this.headers(), headerName);
            }

            /**
             * Follow a related resource
             *
             * The relationship to follow may be define as a plain string, an object
             * with the rel and params, or an array containing one or more entries
             * with the previous forms.
             *
             * Examples:
             *   response.follow('next')
             *
             *   response.follow({ rel: 'next', params: { pageSize: 100 } })
             *
             *   response.follow([
             *       { rel: 'items', params: { projection: 'noImages' } },
             *       'search',
             *       { rel: 'findByGalleryIsNull', params: { projection: 'noImages' } },
             *       'items'
             *   ])
             *
             * @param {String|Object|Array} rels one, or more, relationships to follow
             * @returns ResponsePromise<Response> related resource
             */
            function follow(rels) {
                /*jshint validthis:true */
                rels = [].concat(rels);

                return make(rels.reduce(function(response, rel) {
                    return response.then(function(response) {
                        if (typeof rel === 'string') {
                            rel = {
                                rel: rel
                            };
                        }
                        if (typeof response.entity.clientFor !== 'function') {
                            throw new Error('Hypermedia response expected');
                        }
                        var client = response.entity.clientFor(rel.rel);
                        return client({
                            params: rel.params
                        });
                    });
                }, this));
            }

            /**
             * Wrap a Promise as an ResponsePromise
             *
             * @param {Promise<Response>} promise the promise for an HTTP Response
             * @returns {ResponsePromise<Response>} wrapped promise for Response with additional helper methods
             */
            function make(promise) {
                promise.status = status;
                promise.headers = headers;
                promise.header = header;
                promise.entity = entity;
                promise.follow = follow;
                return promise;
            }

            function responsePromise(obj, callback, errback) {
                return make(Promise.resolve(obj).then(callback, errback));
            }

            responsePromise.make = make;
            responsePromise.reject = function(val) {
                return make(Promise.reject(val));
            };
            responsePromise.promise = function(func) {
                return make(new Promise(func));
            };

            module.exports = responsePromise;

        }, {
            "./normalizeHeaderName": 37
        }],
        39: [function(require, module, exports) {
            /*
             * Copyright 2015-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var charMap;

            charMap = (function() {
                var strings = {
                    alpha: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
                    digit: '0123456789'
                };

                strings.genDelims = ':/?#[]@';
                strings.subDelims = '!$&\'()*+,;=';
                strings.reserved = strings.genDelims + strings.subDelims;
                strings.unreserved = strings.alpha + strings.digit + '-._~';
                strings.url = strings.reserved + strings.unreserved;
                strings.scheme = strings.alpha + strings.digit + '+-.';
                strings.userinfo = strings.unreserved + strings.subDelims + ':';
                strings.host = strings.unreserved + strings.subDelims;
                strings.port = strings.digit;
                strings.pchar = strings.unreserved + strings.subDelims + ':@';
                strings.segment = strings.pchar;
                strings.path = strings.segment + '/';
                strings.query = strings.pchar + '/?';
                strings.fragment = strings.pchar + '/?';

                return Object.keys(strings).reduce(function(charMap, set) {
                    charMap[set] = strings[set].split('').reduce(function(chars, myChar) {
                        chars[myChar] = true;
                        return chars;
                    }, {});
                    return charMap;
                }, {});
            }());

            function encode(str, allowed) {
                if (typeof str !== 'string') {
                    throw new Error('String required for URL encoding');
                }
                return str.split('').map(function(myChar) {
                    if (allowed.hasOwnProperty(myChar)) {
                        return myChar;
                    }
                    var code = myChar.charCodeAt(0);
                    if (code <= 127) {
                        var encoded = code.toString(16).toUpperCase();
                        return '%' + (encoded.length % 2 === 1 ? '0' : '') + encoded;
                    } else {
                        return encodeURIComponent(myChar).toUpperCase();
                    }
                }).join('');
            }

            function makeEncoder(allowed) {
                allowed = allowed || charMap.unreserved;
                return function(str) {
                    return encode(str, allowed);
                };
            }

            function decode(str) {
                return decodeURIComponent(str);
            }

            module.exports = {

                /*
                 * Decode URL encoded strings
                 *
                 * @param {string} URL encoded string
                 * @returns {string} URL decoded string
                 */
                decode: decode,

                /*
                 * URL encode a string
                 *
                 * All but alpha-numerics and a very limited set of punctuation - . _ ~ are
                 * encoded.
                 *
                 * @param {string} string to encode
                 * @returns {string} URL encoded string
                 */
                encode: makeEncoder(),

                /*
                 * URL encode a URL
                 *
                 * All character permitted anywhere in a URL are left unencoded even
                 * if that character is not permitted in that portion of a URL.
                 *
                 * Note: This method is typically not what you want.
                 *
                 * @param {string} string to encode
                 * @returns {string} URL encoded string
                 */
                encodeURL: makeEncoder(charMap.url),

                /*
                 * URL encode the scheme portion of a URL
                 *
                 * @param {string} string to encode
                 * @returns {string} URL encoded string
                 */
                encodeScheme: makeEncoder(charMap.scheme),

                /*
                 * URL encode the user info portion of a URL
                 *
                 * @param {string} string to encode
                 * @returns {string} URL encoded string
                 */
                encodeUserInfo: makeEncoder(charMap.userinfo),

                /*
                 * URL encode the host portion of a URL
                 *
                 * @param {string} string to encode
                 * @returns {string} URL encoded string
                 */
                encodeHost: makeEncoder(charMap.host),

                /*
                 * URL encode the port portion of a URL
                 *
                 * @param {string} string to encode
                 * @returns {string} URL encoded string
                 */
                encodePort: makeEncoder(charMap.port),

                /*
                 * URL encode a path segment portion of a URL
                 *
                 * @param {string} string to encode
                 * @returns {string} URL encoded string
                 */
                encodePathSegment: makeEncoder(charMap.segment),

                /*
                 * URL encode the path portion of a URL
                 *
                 * @param {string} string to encode
                 * @returns {string} URL encoded string
                 */
                encodePath: makeEncoder(charMap.path),

                /*
                 * URL encode the query portion of a URL
                 *
                 * @param {string} string to encode
                 * @returns {string} URL encoded string
                 */
                encodeQuery: makeEncoder(charMap.query),

                /*
                 * URL encode the fragment portion of a URL
                 *
                 * @param {string} string to encode
                 * @returns {string} URL encoded string
                 */
                encodeFragment: makeEncoder(charMap.fragment)

            };

        }, {}],
        40: [function(require, module, exports) {
            /*
             * Copyright 2015-2016 the original author or authors
             * @license MIT, see LICENSE.txt for details
             *
             * @author Scott Andrews
             */

            'use strict';

            var uriEncoder, operations, prefixRE;

            uriEncoder = require('./uriEncoder');

            prefixRE = /^([^:]*):([0-9]+)$/;
            operations = {
                '': {
                    first: '',
                    separator: ',',
                    named: false,
                    empty: '',
                    encoder: uriEncoder.encode
                },
                '+': {
                    first: '',
                    separator: ',',
                    named: false,
                    empty: '',
                    encoder: uriEncoder.encodeURL
                },
                '#': {
                    first: '#',
                    separator: ',',
                    named: false,
                    empty: '',
                    encoder: uriEncoder.encodeURL
                },
                '.': {
                    first: '.',
                    separator: '.',
                    named: false,
                    empty: '',
                    encoder: uriEncoder.encode
                },
                '/': {
                    first: '/',
                    separator: '/',
                    named: false,
                    empty: '',
                    encoder: uriEncoder.encode
                },
                ';': {
                    first: ';',
                    separator: ';',
                    named: true,
                    empty: '',
                    encoder: uriEncoder.encode
                },
                '?': {
                    first: '?',
                    separator: '&',
                    named: true,
                    empty: '=',
                    encoder: uriEncoder.encode
                },
                '&': {
                    first: '&',
                    separator: '&',
                    named: true,
                    empty: '=',
                    encoder: uriEncoder.encode
                },
                '=': {
                    reserved: true
                },
                ',': {
                    reserved: true
                },
                '!': {
                    reserved: true
                },
                '@': {
                    reserved: true
                },
                '|': {
                    reserved: true
                }
            };

            function apply(operation, expression, params) {
                /*jshint maxcomplexity:11 */
                return expression.split(',').reduce(function(result, variable) {
                    var opts, value;

                    opts = {};
                    if (variable.slice(-1) === '*') {
                        variable = variable.slice(0, -1);
                        opts.explode = true;
                    }
                    if (prefixRE.test(variable)) {
                        var prefix = prefixRE.exec(variable);
                        variable = prefix[1];
                        opts.maxLength = parseInt(prefix[2]);
                    }

                    variable = uriEncoder.decode(variable);
                    value = params[variable];

                    if (value === void 0 || value === null) {
                        return result;
                    }
                    if (Array.isArray(value)) {
                        result = value.reduce(function(result, value) {
                            if (result.length) {
                                result += opts.explode ? operation.separator : ',';
                                if (operation.named && opts.explode) {
                                    result += operation.encoder(variable);
                                    result += value.length ? '=' : operation.empty;
                                }
                            } else {
                                result += operation.first;
                                if (operation.named) {
                                    result += operation.encoder(variable);
                                    result += value.length ? '=' : operation.empty;
                                }
                            }
                            result += operation.encoder(value);
                            return result;
                        }, result);
                    } else if (typeof value === 'object') {
                        result = Object.keys(value).reduce(function(result, name) {
                            if (result.length) {
                                result += opts.explode ? operation.separator : ',';
                            } else {
                                result += operation.first;
                                if (operation.named && !opts.explode) {
                                    result += operation.encoder(variable);
                                    result += value[name].length ? '=' : operation.empty;
                                }
                            }
                            result += operation.encoder(name);
                            result += opts.explode ? '=' : ',';
                            result += operation.encoder(value[name]);
                            return result;
                        }, result);
                    } else {
                        value = String(value);
                        if (opts.maxLength) {
                            value = value.slice(0, opts.maxLength);
                        }
                        result += result.length ? operation.separator : operation.first;
                        if (operation.named) {
                            result += operation.encoder(variable);
                            result += value.length ? '=' : operation.empty;
                        }
                        result += operation.encoder(value);
                    }

                    return result;
                }, '');
            }

            function expandExpression(expression, params) {
                var operation;

                operation = operations[expression.slice(0, 1)];
                if (operation) {
                    expression = expression.slice(1);
                } else {
                    operation = operations[''];
                }

                if (operation.reserved) {
                    throw new Error('Reserved expression operations are not supported');
                }

                return apply(operation, expression, params);
            }

            function expandTemplate(template, params) {
                var start, end, uri;

                uri = '';
                end = 0;
                while (true) {
                    start = template.indexOf('{', end);
                    if (start === -1) {
                        // no more expressions
                        uri += template.slice(end);
                        break;
                    }
                    uri += template.slice(end, start);
                    end = template.indexOf('}', start) + 1;
                    uri += expandExpression(template.slice(start + 1, end - 1), params);
                }

                return uri;
            }

            module.exports = {

                /**
                 * Expand a URI Template with parameters to form a URI.
                 *
                 * Full implementation (level 4) of rfc6570.
                 * @see https://tools.ietf.org/html/rfc6570
                 *
                 * @param {string} template URI template
                 * @param {Object} [params] params to apply to the template durring expantion
                 * @returns {string} expanded URI
                 */
                expand: expandTemplate

            };

        }, {
            "./uriEncoder": 39
        }],
        41: [function(require, module, exports) {
            (function(process) {
                /*
                 * Copyright 2013-2015, Facebook, Inc.
                 * All rights reserved.
                 *
                 * This source code is licensed under the BSD-style license found in the
                 * LICENSE file in the root directory of this source tree. An additional grant
                 * of patent rights can be found in the PATENTS file in the same directory.
                 */

                'use strict';

                /*
                 * Use invariant() to assert state which your program assumes to be true.
                 *
                 * Provide sprintf-style format (only %s is supported) and arguments
                 * to provide information about what broke and what you were
                 * expecting.
                 *
                 * The invariant message will be stripped in production, but the invariant
                 * will remain to ensure logic does not differ in production.
                 */

                var NODE_ENV = process.env.NODE_ENV;

                var invariant = function(condition, format, a, b, c, d, e, f) {
                    if (NODE_ENV !== 'production') {
                        if (format === undefined) {
                            throw new Error('invariant requires an error message argument');
                        }
                    }

                    if (!condition) {
                        var error;
                        if (format === undefined) {
                            error = new Error(
                                'Minified exception occurred; use the non-minified dev environment ' +
                                'for the full error message and additional helpful warnings.'
                            );
                        } else {
                            var args = [a, b, c, d, e, f];
                            var argIndex = 0;
                            error = new Error(
                                format.replace(/%s/g, function() {
                                    return args[argIndex++];
                                })
                            );
                            error.name = 'Invariant Violation';
                        }

                        error.framesToPop = 1; // we don't care about invariant's own frame
                        throw error;
                    }
                };

                module.exports = invariant;

            }).call(this, require('_process'))
        }, {
            "_process": 4
        }],
        42: [function(require, module, exports) {
            (function(process, global) {
                ! function(t) {
                    "object" == typeof exports ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : "undefined" != typeof window ? window.Promise = t() : "undefined" != typeof global ? global.Promise = t() : "undefined" != typeof self && (self.Promise = t())
                }(function() {
                    var t;
                    return function e(t, n, o) {
                        function r(u, c) {
                            if (!n[u]) {
                                if (!t[u]) {
                                    var f = "function" == typeof require && require;
                                    if (!c && f) return f(u, !0);
                                    if (i) return i(u, !0);
                                    throw new Error("Cannot find module '" + u + "'")
                                }
                                var s = n[u] = {
                                    exports: {}
                                };
                                t[u][0].call(s.exports, function(e) {
                                    var n = t[u][1][e];
                                    return r(n ? n : e)
                                }, s, s.exports, e, t, n, o)
                            }
                            return n[u].exports
                        }
                        for (var i = "function" == typeof require && require, u = 0; u < o.length; u++) r(o[u]);
                        return r
                    }({
                        1: [function(t, e, n) {
                            var o = t("../lib/decorators/unhandledRejection"),
                                r = o(t("../lib/Promise"));
                            e.exports = "undefined" != typeof global ? global.Promise = r : "undefined" != typeof self ? self.Promise = r : r
                        }, {
                            "../lib/Promise": 2,
                            "../lib/decorators/unhandledRejection": 4
                        }],
                        2: [function(e, n, o) {
                            ! function(t) {
                                "use strict";
                                t(function(t) {
                                    var e = t("./makePromise"),
                                        n = t("./Scheduler"),
                                        o = t("./env").asap;
                                    return e({
                                        scheduler: new n(o)
                                    })
                                })
                            }("function" == typeof t && t.amd ? t : function(t) {
                                n.exports = t(e)
                            })
                        }, {
                            "./Scheduler": 3,
                            "./env": 5,
                            "./makePromise": 7
                        }],
                        3: [function(e, n, o) {
                            ! function(t) {
                                "use strict";
                                t(function() {
                                    function t(t) {
                                        this._async = t, this._running = !1, this._queue = this, this._queueLen = 0, this._afterQueue = {}, this._afterQueueLen = 0;
                                        var e = this;
                                        this.drain = function() {
                                            e._drain()
                                        }
                                    }
                                    return t.prototype.enqueue = function(t) {
                                        this._queue[this._queueLen++] = t, this.run()
                                    }, t.prototype.afterQueue = function(t) {
                                        this._afterQueue[this._afterQueueLen++] = t, this.run()
                                    }, t.prototype.run = function() {
                                        this._running || (this._running = !0, this._async(this.drain))
                                    }, t.prototype._drain = function() {
                                        for (var t = 0; t < this._queueLen; ++t) this._queue[t].run(), this._queue[t] = void 0;
                                        for (this._queueLen = 0, this._running = !1, t = 0; t < this._afterQueueLen; ++t) this._afterQueue[t].run(), this._afterQueue[t] = void 0;
                                        this._afterQueueLen = 0
                                    }, t
                                })
                            }("function" == typeof t && t.amd ? t : function(t) {
                                n.exports = t()
                            })
                        }, {}],
                        4: [function(e, n, o) {
                            ! function(t) {
                                "use strict";
                                t(function(t) {
                                    function e(t) {
                                        throw t
                                    }

                                    function n() {}
                                    var o = t("../env").setTimer,
                                        r = t("../format");
                                    return function(t) {
                                        function i(t) {
                                            t.handled || (l.push(t), a("Potentially unhandled rejection [" + t.id + "] " + r.formatError(t.value)))
                                        }

                                        function u(t) {
                                            var e = l.indexOf(t);
                                            e >= 0 && (l.splice(e, 1), h("Handled previous rejection [" + t.id + "] " + r.formatObject(t.value)))
                                        }

                                        function c(t, e) {
                                            p.push(t, e), null === d && (d = o(f, 0))
                                        }

                                        function f() {
                                            for (d = null; p.length > 0;) p.shift()(p.shift())
                                        }
                                        var s, a = n,
                                            h = n;
                                        "undefined" != typeof console && (s = console, a = "undefined" != typeof s.error ? function(t) {
                                            s.error(t)
                                        } : function(t) {
                                            s.log(t)
                                        }, h = "undefined" != typeof s.info ? function(t) {
                                            s.info(t)
                                        } : function(t) {
                                            s.log(t)
                                        }), t.onPotentiallyUnhandledRejection = function(t) {
                                            c(i, t)
                                        }, t.onPotentiallyUnhandledRejectionHandled = function(t) {
                                            c(u, t)
                                        }, t.onFatalRejection = function(t) {
                                            c(e, t.value)
                                        };
                                        var p = [],
                                            l = [],
                                            d = null;
                                        return t
                                    }
                                })
                            }("function" == typeof t && t.amd ? t : function(t) {
                                n.exports = t(e)
                            })
                        }, {
                            "../env": 5,
                            "../format": 6
                        }],
                        5: [function(e, n, o) {
                            ! function(t) {
                                "use strict";
                                t(function(t) {
                                    function e() {
                                        return "undefined" != typeof process && "[object process]" === Object.prototype.toString.call(process)
                                    }

                                    function n() {
                                        return "function" == typeof MutationObserver && MutationObserver || "function" == typeof WebKitMutationObserver && WebKitMutationObserver
                                    }

                                    function o(t) {
                                        function e() {
                                            var t = n;
                                            n = void 0, t()
                                        }
                                        var n, o = document.createTextNode(""),
                                            r = new t(e);
                                        r.observe(o, {
                                            characterData: !0
                                        });
                                        var i = 0;
                                        return function(t) {
                                            n = t, o.data = i ^= 1
                                        }
                                    }
                                    var r, i = "undefined" != typeof setTimeout && setTimeout,
                                        u = function(t, e) {
                                            return setTimeout(t, e)
                                        },
                                        c = function(t) {
                                            return clearTimeout(t)
                                        },
                                        f = function(t) {
                                            return i(t, 0)
                                        };
                                    if (e()) f = function(t) {
                                        return process.nextTick(t)
                                    };
                                    else if (r = n()) f = o(r);
                                    else if (!i) {
                                        var s = t,
                                            a = s("vertx");
                                        u = function(t, e) {
                                            return a.setTimer(e, t)
                                        }, c = a.cancelTimer, f = a.runOnLoop || a.runOnContext
                                    }
                                    return {
                                        setTimer: u,
                                        clearTimer: c,
                                        asap: f
                                    }
                                })
                            }("function" == typeof t && t.amd ? t : function(t) {
                                n.exports = t(e)
                            })
                        }, {}],
                        6: [function(e, n, o) {
                            ! function(t) {
                                "use strict";
                                t(function() {
                                    function t(t) {
                                        var n = "object" == typeof t && null !== t && (t.stack || t.message) ? t.stack || t.message : e(t);
                                        return t instanceof Error ? n : n + " (WARNING: non-Error used)"
                                    }

                                    function e(t) {
                                        var e = String(t);
                                        return "[object Object]" === e && "undefined" != typeof JSON && (e = n(t, e)), e
                                    }

                                    function n(t, e) {
                                        try {
                                            return JSON.stringify(t)
                                        } catch (n) {
                                            return e
                                        }
                                    }
                                    return {
                                        formatError: t,
                                        formatObject: e,
                                        tryStringify: n
                                    }
                                })
                            }("function" == typeof t && t.amd ? t : function(t) {
                                n.exports = t()
                            })
                        }, {}],
                        7: [function(e, n, o) {
                            ! function(t) {
                                "use strict";
                                t(function() {
                                    return function(t) {
                                        function e(t, e) {
                                            this._handler = t === _ ? e : n(t)
                                        }

                                        function n(t) {
                                            function e(t) {
                                                r.resolve(t)
                                            }

                                            function n(t) {
                                                r.reject(t)
                                            }

                                            function o(t) {
                                                r.notify(t)
                                            }
                                            var r = new b;
                                            try {
                                                t(e, n, o)
                                            } catch (i) {
                                                n(i)
                                            }
                                            return r
                                        }

                                        function o(t) {
                                            return S(t) ? t : new e(_, new x(y(t)))
                                        }

                                        function r(t) {
                                            return new e(_, new x(new P(t)))
                                        }

                                        function i() {
                                            return $
                                        }

                                        function u() {
                                            return new e(_, new b)
                                        }

                                        function c(t, e) {
                                            var n = new b(t.receiver, t.join().context);
                                            return new e(_, n)
                                        }

                                        function f(t) {
                                            return a(K, null, t)
                                        }

                                        function s(t, e) {
                                            return a(F, t, e)
                                        }

                                        function a(t, n, o) {
                                            function r(e, r, u) {
                                                u.resolved || h(o, i, e, t(n, r, e), u)
                                            }

                                            function i(t, e, n) {
                                                a[t] = e, 0 === --s && n.become(new q(a))
                                            }
                                            for (var u, c = "function" == typeof n ? r : i, f = new b, s = o.length >>> 0, a = new Array(s), p = 0; p < o.length && !f.resolved; ++p) u = o[p], void 0 !== u || p in o ? h(o, c, p, u, f) : --s;
                                            return 0 === s && f.become(new q(a)), new e(_, f)
                                        }

                                        function h(t, e, n, o, r) {
                                            if (U(o)) {
                                                var i = m(o),
                                                    u = i.state();
                                                0 === u ? i.fold(e, n, void 0, r) : u > 0 ? e(n, i.value, r) : (r.become(i), p(t, n + 1, i))
                                            } else e(n, o, r)
                                        }

                                        function p(t, e, n) {
                                            for (var o = e; o < t.length; ++o) l(y(t[o]), n)
                                        }

                                        function l(t, e) {
                                            if (t !== e) {
                                                var n = t.state();
                                                0 === n ? t.visit(t, void 0, t._unreport) : 0 > n && t._unreport()
                                            }
                                        }

                                        function d(t) {
                                            return "object" != typeof t || null === t ? r(new TypeError("non-iterable passed to race()")) : 0 === t.length ? i() : 1 === t.length ? o(t[0]) : v(t)
                                        }

                                        function v(t) {
                                            var n, o, r, i = new b;
                                            for (n = 0; n < t.length; ++n)
                                                if (o = t[n], void 0 !== o || n in t) {
                                                    if (r = y(o), 0 !== r.state()) {
                                                        i.become(r), p(t, n + 1, r);
                                                        break
                                                    }
                                                    r.visit(i, i.resolve, i.reject)
                                                }
                                            return new e(_, i)
                                        }

                                        function y(t) {
                                            return S(t) ? t._handler.join() : U(t) ? j(t) : new q(t)
                                        }

                                        function m(t) {
                                            return S(t) ? t._handler.join() : j(t)
                                        }

                                        function j(t) {
                                            try {
                                                var e = t.then;
                                                return "function" == typeof e ? new g(e, t) : new q(t)
                                            } catch (n) {
                                                return new P(n)
                                            }
                                        }

                                        function _() {}

                                        function w() {}

                                        function b(t, n) {
                                            e.createContext(this, n), this.consumers = void 0, this.receiver = t, this.handler = void 0, this.resolved = !1
                                        }

                                        function x(t) {
                                            this.handler = t
                                        }

                                        function g(t, e) {
                                            b.call(this), I.enqueue(new E(t, e, this))
                                        }

                                        function q(t) {
                                            e.createContext(this), this.value = t
                                        }

                                        function P(t) {
                                            e.createContext(this), this.id = ++Y, this.value = t, this.handled = !1, this.reported = !1, this._report()
                                        }

                                        function R(t, e) {
                                            this.rejection = t, this.context = e
                                        }

                                        function C(t) {
                                            this.rejection = t
                                        }

                                        function O() {
                                            return new P(new TypeError("Promise cycle"))
                                        }

                                        function T(t, e) {
                                            this.continuation = t, this.handler = e
                                        }

                                        function Q(t, e) {
                                            this.handler = e, this.value = t
                                        }

                                        function E(t, e, n) {
                                            this._then = t, this.thenable = e, this.resolver = n
                                        }

                                        function L(t, e, n, o, r) {
                                            try {
                                                t.call(e, n, o, r)
                                            } catch (i) {
                                                o(i)
                                            }
                                        }

                                        function k(t, e, n, o) {
                                            this.f = t, this.z = e, this.c = n, this.to = o, this.resolver = X, this.receiver = this
                                        }

                                        function S(t) {
                                            return t instanceof e
                                        }

                                        function U(t) {
                                            return ("object" == typeof t || "function" == typeof t) && null !== t
                                        }

                                        function H(t, n, o, r) {
                                            return "function" != typeof t ? r.become(n) : (e.enterContext(n), W(t, n.value, o, r), void e.exitContext())
                                        }

                                        function N(t, n, o, r, i) {
                                            return "function" != typeof t ? i.become(o) : (e.enterContext(o), z(t, n, o.value, r, i), void e.exitContext())
                                        }

                                        function M(t, n, o, r, i) {
                                            return "function" != typeof t ? i.notify(n) : (e.enterContext(o), A(t, n, r, i), void e.exitContext())
                                        }

                                        function F(t, e, n) {
                                            try {
                                                return t(e, n)
                                            } catch (o) {
                                                return r(o)
                                            }
                                        }

                                        function W(t, e, n, o) {
                                            try {
                                                o.become(y(t.call(n, e)))
                                            } catch (r) {
                                                o.become(new P(r))
                                            }
                                        }

                                        function z(t, e, n, o, r) {
                                            try {
                                                t.call(o, e, n, r)
                                            } catch (i) {
                                                r.become(new P(i))
                                            }
                                        }

                                        function A(t, e, n, o) {
                                            try {
                                                o.notify(t.call(n, e))
                                            } catch (r) {
                                                o.notify(r)
                                            }
                                        }

                                        function J(t, e) {
                                            e.prototype = V(t.prototype), e.prototype.constructor = e
                                        }

                                        function K(t, e) {
                                            return e
                                        }

                                        function D() {}

                                        function G() {
                                            return "undefined" != typeof process && null !== process && "function" == typeof process.emit ? function(t, e) {
                                                return "unhandledRejection" === t ? process.emit(t, e.value, e) : process.emit(t, e)
                                            } : "undefined" != typeof self && "function" == typeof CustomEvent ? function(t, e, n) {
                                                var o = !1;
                                                try {
                                                    var r = new n("unhandledRejection");
                                                    o = r instanceof n
                                                } catch (i) {}
                                                return o ? function(t, o) {
                                                    var r = new n(t, {
                                                        detail: {
                                                            reason: o.value,
                                                            key: o
                                                        },
                                                        bubbles: !1,
                                                        cancelable: !0
                                                    });
                                                    return !e.dispatchEvent(r)
                                                } : t
                                            }(D, self, CustomEvent) : D
                                        }
                                        var I = t.scheduler,
                                            B = G(),
                                            V = Object.create || function(t) {
                                                function e() {}
                                                return e.prototype = t, new e
                                            };
                                        e.resolve = o, e.reject = r, e.never = i, e._defer = u, e._handler = y, e.prototype.then = function(t, e, n) {
                                            var o = this._handler,
                                                r = o.join().state();
                                            if ("function" != typeof t && r > 0 || "function" != typeof e && 0 > r) return new this.constructor(_, o);
                                            var i = this._beget(),
                                                u = i._handler;
                                            return o.chain(u, o.receiver, t, e, n), i
                                        }, e.prototype["catch"] = function(t) {
                                            return this.then(void 0, t)
                                        }, e.prototype._beget = function() {
                                            return c(this._handler, this.constructor)
                                        }, e.all = f, e.race = d, e._traverse = s, e._visitRemaining = p, _.prototype.when = _.prototype.become = _.prototype.notify = _.prototype.fail = _.prototype._unreport = _.prototype._report = D, _.prototype._state = 0, _.prototype.state = function() {
                                            return this._state
                                        }, _.prototype.join = function() {
                                            for (var t = this; void 0 !== t.handler;) t = t.handler;
                                            return t
                                        }, _.prototype.chain = function(t, e, n, o, r) {
                                            this.when({
                                                resolver: t,
                                                receiver: e,
                                                fulfilled: n,
                                                rejected: o,
                                                progress: r
                                            })
                                        }, _.prototype.visit = function(t, e, n, o) {
                                            this.chain(X, t, e, n, o)
                                        }, _.prototype.fold = function(t, e, n, o) {
                                            this.when(new k(t, e, n, o))
                                        }, J(_, w), w.prototype.become = function(t) {
                                            t.fail()
                                        };
                                        var X = new w;
                                        J(_, b), b.prototype._state = 0, b.prototype.resolve = function(t) {
                                            this.become(y(t))
                                        }, b.prototype.reject = function(t) {
                                            this.resolved || this.become(new P(t))
                                        }, b.prototype.join = function() {
                                            if (!this.resolved) return this;
                                            for (var t = this; void 0 !== t.handler;)
                                                if (t = t.handler, t === this) return this.handler = O();
                                            return t
                                        }, b.prototype.run = function() {
                                            var t = this.consumers,
                                                e = this.handler;
                                            this.handler = this.handler.join(), this.consumers = void 0;
                                            for (var n = 0; n < t.length; ++n) e.when(t[n])
                                        }, b.prototype.become = function(t) {
                                            this.resolved || (this.resolved = !0, this.handler = t, void 0 !== this.consumers && I.enqueue(this), void 0 !== this.context && t._report(this.context))
                                        }, b.prototype.when = function(t) {
                                            this.resolved ? I.enqueue(new T(t, this.handler)) : void 0 === this.consumers ? this.consumers = [t] : this.consumers.push(t)
                                        }, b.prototype.notify = function(t) {
                                            this.resolved || I.enqueue(new Q(t, this))
                                        }, b.prototype.fail = function(t) {
                                            var e = "undefined" == typeof t ? this.context : t;
                                            this.resolved && this.handler.join().fail(e)
                                        }, b.prototype._report = function(t) {
                                            this.resolved && this.handler.join()._report(t)
                                        }, b.prototype._unreport = function() {
                                            this.resolved && this.handler.join()._unreport()
                                        }, J(_, x), x.prototype.when = function(t) {
                                            I.enqueue(new T(t, this))
                                        }, x.prototype._report = function(t) {
                                            this.join()._report(t)
                                        }, x.prototype._unreport = function() {
                                            this.join()._unreport()
                                        }, J(b, g), J(_, q), q.prototype._state = 1, q.prototype.fold = function(t, e, n, o) {
                                            N(t, e, this, n, o)
                                        }, q.prototype.when = function(t) {
                                            H(t.fulfilled, this, t.receiver, t.resolver)
                                        };
                                        var Y = 0;
                                        J(_, P), P.prototype._state = -1, P.prototype.fold = function(t, e, n, o) {
                                            o.become(this)
                                        }, P.prototype.when = function(t) {
                                            "function" == typeof t.rejected && this._unreport(), H(t.rejected, this, t.receiver, t.resolver)
                                        }, P.prototype._report = function(t) {
                                            I.afterQueue(new R(this, t))
                                        }, P.prototype._unreport = function() {
                                            this.handled || (this.handled = !0, I.afterQueue(new C(this)))
                                        }, P.prototype.fail = function(t) {
                                            this.reported = !0, B("unhandledRejection", this), e.onFatalRejection(this, void 0 === t ? this.context : t)
                                        }, R.prototype.run = function() {
                                            this.rejection.handled || this.rejection.reported || (this.rejection.reported = !0, B("unhandledRejection", this.rejection) || e.onPotentiallyUnhandledRejection(this.rejection, this.context))
                                        }, C.prototype.run = function() {
                                            this.rejection.reported && (B("rejectionHandled", this.rejection) || e.onPotentiallyUnhandledRejectionHandled(this.rejection))
                                        }, e.createContext = e.enterContext = e.exitContext = e.onPotentiallyUnhandledRejection = e.onPotentiallyUnhandledRejectionHandled = e.onFatalRejection = D;
                                        var Z = new _,
                                            $ = new e(_, Z);
                                        return T.prototype.run = function() {
                                            this.handler.join().when(this.continuation)
                                        }, Q.prototype.run = function() {
                                            var t = this.handler.consumers;
                                            if (void 0 !== t)
                                                for (var e, n = 0; n < t.length; ++n) e = t[n], M(e.progress, this.value, this.handler, e.receiver, e.resolver)
                                        }, E.prototype.run = function() {
                                            function t(t) {
                                                o.resolve(t)
                                            }

                                            function e(t) {
                                                o.reject(t)
                                            }

                                            function n(t) {
                                                o.notify(t)
                                            }
                                            var o = this.resolver;
                                            L(this._then, this.thenable, t, e, n)
                                        }, k.prototype.fulfilled = function(t) {
                                            this.f.call(this.c, this.z, t, this.to)
                                        }, k.prototype.rejected = function(t) {
                                            this.to.reject(t)
                                        }, k.prototype.progress = function(t) {
                                            this.to.notify(t)
                                        }, e
                                    }
                                })
                            }("function" == typeof t && t.amd ? t : function(t) {
                                n.exports = t()
                            })
                        }, {}]
                    }, {}, [1])(1)
                });


            }).call(this, require('_process'), typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
        }, {
            "_process": 4
        }],
        43: [function(require, module, exports) {
            'use strict';

            /**
             * A typeahead component for inputs
             * @class Suggestions
             *
             * @param {HTMLInputElement} el A valid HTML input element
             * @param {Array} data An array of data used for results
             * @param {Object} options
             * @param {Number} [options.limit=5] Max number of results to display in the auto suggest list.
             * @param {Number} [options.minLength=2] Number of characters typed into an input to trigger suggestions.
             * @return {Suggestions} `this`
             * @example
             * // in the browser
             * var input = document.querySelector('input');
             * var data = [
             *   'Roy Eldridge',
             *   'Roy Hargrove',
             *   'Rex Stewart'
             * ];
             *
             * new Suggestions(input, data);
             *
             * // with options
             * var input = document.querySelector('input');
             * var data = [{
             *   name: 'Roy Eldridge',
             *   year: 1911
             * }, {
             *   name: 'Roy Hargrove',
             *   year: 1969
             * }, {
             *   name: 'Rex Stewart',
             *   year: 1907
             * }];
             *
             * var typeahead = new Suggestions(input, data, {
             *   filter: false, // Disable filtering
             *   minLength: 3, // Number of characters typed into an input to trigger suggestions.
             *   limit: 3 //  Max number of results to display.
             * });
             *
             * // As we're passing an object of an arrays as data, override
             * // `getItemValue` by specifying the specific property to search on.
             * typeahead.getItemValue = function(item) { return item.name };
             *
             * input.addEventListener('change', function() {
             *   console.log(typeahead.selected); // Current selected item.
             * });
             *
             * // With browserify
             * var Suggestions = require('suggestions');
             *
             * new Suggestions(input, data);
             */
            var Suggestions = require('./src/suggestions');
            window.Suggestions = module.exports = Suggestions;

        }, {
            "./src/suggestions": 46
        }],
        44: [function(require, module, exports) {
            /*
             * Fuzzy
             * https://github.com/myork/fuzzy
             *
             * Copyright (c) 2012 Matt York
             * Licensed under the MIT license.
             */

            (function() {

                var root = this;

                var fuzzy = {};

                // Use in node or in browser
                if (typeof exports !== 'undefined') {
                    module.exports = fuzzy;
                } else {
                    root.fuzzy = fuzzy;
                }

                // Return all elements of `array` that have a fuzzy
                // match against `pattern`.
                fuzzy.simpleFilter = function(pattern, array) {
                    return array.filter(function(str) {
                        return fuzzy.test(pattern, str);
                    });
                };

                // Does `pattern` fuzzy match `str`?
                fuzzy.test = function(pattern, str) {
                    return fuzzy.match(pattern, str) !== null;
                };

                // If `pattern` matches `str`, wrap each matching character
                // in `opts.pre` and `opts.post`. If no match, return null
                fuzzy.match = function(pattern, str, opts) {
                    opts = opts || {};
                    var patternIdx = 0,
                        result = [],
                        len = str.length,
                        totalScore = 0,
                        currScore = 0
                        // prefix
                        ,
                        pre = opts.pre || ''
                        // suffix
                        ,
                        post = opts.post || ''
                        // String to compare against. This might be a lowercase version of the
                        // raw string
                        ,
                        compareString = opts.caseSensitive && str || str.toLowerCase(),
                        ch;

                    pattern = opts.caseSensitive && pattern || pattern.toLowerCase();

                    // For each character in the string, either add it to the result
                    // or wrap in template if it's the next string in the pattern
                    for (var idx = 0; idx < len; idx++) {
                        ch = str[idx];
                        if (compareString[idx] === pattern[patternIdx]) {
                            ch = pre + ch + post;
                            patternIdx += 1;

                            // consecutive characters should increase the score more than linearly
                            currScore += 1 + currScore;
                        } else {
                            currScore = 0;
                        }
                        totalScore += currScore;
                        result[result.length] = ch;
                    }

                    // return rendered string if we have a match for every char
                    if (patternIdx === pattern.length) {
                        // if the string is an exact match with pattern, totalScore should be maxed
                        totalScore = (compareString === pattern) ? Infinity : totalScore;
                        return {
                            rendered: result.join(''),
                            score: totalScore
                        };
                    }

                    return null;
                };

                // The normal entry point. Filters `arr` for matches against `pattern`.
                // It returns an array with matching values of the type:
                //
                //     [{
                //         string:   '<b>lah' // The rendered string
                //       , index:    2        // The index of the element in `arr`
                //       , original: 'blah'   // The original element in `arr`
                //     }]
                //
                // `opts` is an optional argument bag. Details:
                //
                //    opts = {
                //        // string to put before a matching character
                //        pre:     '<b>'
                //
                //        // string to put after matching character
                //      , post:    '</b>'
                //
                //        // Optional function. Input is an entry in the given arr`,
                //        // output should be the string to test `pattern` against.
                //        // In this example, if `arr = [{crying: 'koala'}]` we would return
                //        // 'koala'.
                //      , extract: function(arg) { return arg.crying; }
                //    }
                fuzzy.filter = function(pattern, arr, opts) {
                    if (!arr || arr.length === 0) {
                        return [];
                    }
                    if (typeof pattern !== 'string') {
                        return arr;
                    }
                    opts = opts || {};
                    return arr
                        .reduce(function(prev, element, idx, arr) {
                            var str = element;
                            if (opts.extract) {
                                str = opts.extract(element);
                            }
                            var rendered = fuzzy.match(pattern, str, opts);
                            if (rendered != null) {
                                prev[prev.length] = {
                                    string: rendered.rendered,
                                    score: rendered.score,
                                    index: idx,
                                    original: element
                                };
                            }
                            return prev;
                        }, [])

                        // Sort by score. Browsers are inconsistent wrt stable/unstable
                        // sorting, so force stable by using the index in the case of tie.
                        // See http://ofb.net/~sethml/is-sort-stable.html
                        .sort(function(a, b) {
                            var compare = b.score - a.score;
                            if (compare) return compare;
                            return a.index - b.index;
                        });
                };


            }());


        }, {}],
        45: [function(require, module, exports) {
            'Use strict';

            var List = function(component) {
                this.component = component;
                this.items = [];
                this.active = 0;
                this.element = document.createElement('ul');
                this.element.className = 'suggestions';

                component.el.parentNode.insertBefore(this.element, component.el.nextSibling);
                return this;
            };

            List.prototype.show = function() {
                this.element.style.display = 'block';
            };

            List.prototype.hide = function() {
                this.element.style.display = 'none';
            };

            List.prototype.add = function(item) {
                this.items.push(item);
            };

            List.prototype.clear = function() {
                this.items = [];
                this.active = 0;
            };

            List.prototype.isEmpty = function() {
                return !this.items.length;
            };

            List.prototype.draw = function() {
                this.element.innerHTML = '';

                if (this.items.length === 0) {
                    this.hide();
                    return;
                }

                for (var i = 0; i < this.items.length; i++) {
                    this.drawItem(this.items[i], this.active === i);
                }

                this.show();
            };

            List.prototype.drawItem = function(item, active) {
                var li = document.createElement('li'),
                    a = document.createElement('a');

                if (active) li.className += ' active';

                a.innerHTML = item.string;

                li.appendChild(a);
                this.element.appendChild(li);

                li.addEventListener('mousedown', function() {
                    this.handleMouseDown.call(this, item);
                }.bind(this));
            };

            List.prototype.handleMouseDown = function(item) {
                this.component.value(item.original);
                this.clear();
                this.draw();
            };

            List.prototype.move = function(index) {
                this.active = index;
                this.draw();
            };

            List.prototype.previous = function() {
                this.move(this.active === 0 ? this.items.length - 1 : this.active - 1);
            };

            List.prototype.next = function() {
                this.move(this.active === this.items.length - 1 ? 0 : this.active + 1);
            };

            module.exports = List;

        }, {}],
        46: [function(require, module, exports) {
            'use strict';

            var extend = require('xtend');
            var fuzzy = require('fuzzy');
            var List = require('./list');

            var Suggestions = function(el, data, options) {
                options = options || {};

                this.options = extend({
                    minLength: 2,
                    limit: 5,
                    filter: true
                }, options);

                this.el = el;
                this.data = data || [];
                this.list = new List(this);

                this.query = '';
                this.selected = null;

                this.list.draw();

                this.el.addEventListener('keyup', function(e) {
                    this.handleKeyUp(e.keyCode);
                }.bind(this), false);

                this.el.addEventListener('keydown', function(e) {
                    this.handleKeyDown(e);
                }.bind(this));

                this.el.addEventListener('focus', function() {
                    this.handleFocus();
                }.bind(this));

                this.el.addEventListener('blur', function() {
                    this.handleBlur();
                }.bind(this));

                return this;
            };

            Suggestions.prototype.handleKeyUp = function(keyCode) {
                // 40 - DOWN
                // 38 - UP
                // 27 - ESC
                // 13 - ENTER
                // 9 - TAB

                if (keyCode === 40 ||
                    keyCode === 38 ||
                    keyCode === 27 ||
                    keyCode === 13 ||
                    keyCode === 9) return;

                this.query = this.normalize(this.el.value);

                this.list.clear();

                if (this.query.length < this.options.minLength) {
                    this.list.draw();
                    return;
                }

                this.getCandidates(function(data) {
                    for (var i = 0; i < data.length; i++) {
                        this.list.add(data[i]);
                        if (i === (this.options.limit - 1)) break;
                    }
                    this.list.draw();
                }.bind(this));
            };

            Suggestions.prototype.handleKeyDown = function(e) {
                switch (e.keyCode) {
                    case 13: // ENTER
                    case 9: // TAB
                        if (!this.list.isEmpty()) {
                            this.value(this.list.items[this.list.active].original);
                            this.list.hide();
                        }
                        break;
                    case 27: // ESC
                        if (!this.list.isEmpty()) this.list.hide();
                        break;
                    case 38: // UP
                        this.list.previous();
                        break;
                    case 40: // DOWN
                        this.list.next();
                        break;
                }
            };

            Suggestions.prototype.handleBlur = function() {
                this.list.hide();
            };

            Suggestions.prototype.handleFocus = function() {
                if (!this.list.isEmpty()) this.list.show();
            };

            /**
             * Update data previously passed
             *
             * @param {Array} revisedData
             */
            Suggestions.prototype.update = function(revisedData) {
                this.data = revisedData;
                this.handleKeyUp();
            };

            /**
             * Clears data
             */
            Suggestions.prototype.clear = function() {
                this.data = [];
                this.list.clear();
            };

            /**
             * Normalize the results list and input value for matching
             *
             * @param {String} value
             * @return {String}
             */
            Suggestions.prototype.normalize = function(value) {
                value = value.toLowerCase();
                return value;
            };

            /**
             * Evaluates whether an array item qualifies as a match with the current query
             *
             * @param {String} candidate a possible item from the array passed
             * @param {String} query the current query
             * @return {Boolean}
             */
            Suggestions.prototype.match = function(candidate, query) {
                return candidate.indexOf(query) > -1;
            };

            Suggestions.prototype.value = function(value) {
                this.selected = value;
                this.el.value = this.getItemValue(value);

                if (document.createEvent) {
                    var e = document.createEvent('HTMLEvents');
                    e.initEvent('change', true, false);
                    this.el.dispatchEvent(e);
                } else {
                    this.el.fireEvent('onchange');
                }
            };

            Suggestions.prototype.getCandidates = function(callback) {
                var options = {
                    pre: '<strong>',
                    post: '</strong>',
                    extract: function(d) {
                        return this.getItemValue(d);
                    }.bind(this)
                };

                var results = this.options.filter ?
                    fuzzy.filter(this.query, this.data, options) :
                    this.data.map(function(d) {
                        return {
                            original: d,
                            string: this.getItemValue(d).replace(new RegExp('(' + this.query + ')', 'ig'), function($1, match) {
                                return '<strong>' + match + '</strong>';
                            })
                        };
                    }.bind(this));

                callback(results);
            };

            /**
             * For a given item in the data array, return what should be used as the candidate string
             *
             * @param {Object|String} item an item from the data array
             * @return {String} item
             */
            Suggestions.prototype.getItemValue = function(item) {
                return item;
            };

            module.exports = Suggestions;

        }, {
            "./list": 45,
            "fuzzy": 44,
            "xtend": 47
        }],
        47: [function(require, module, exports) {
            module.exports = extend

            var hasOwnProperty = Object.prototype.hasOwnProperty;

            function extend() {
                var target = {}

                for (var i = 0; i < arguments.length; i++) {
                    var source = arguments[i]

                    for (var key in source) {
                        if (hasOwnProperty.call(source, key)) {
                            target[key] = source[key]
                        }
                    }
                }

                return target
            }

        }, {}]
    }, {}, [2])(2)
});